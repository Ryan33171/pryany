PRYANY
1.WIRTTER:Ryan33171,Chinese
2.VERSION:1.2.3Test
3.Space:(no runtool):12.1MB
4.Depend on the runner:g++
5.Language:C++17
6.File directory:
	README.txt
	pryany.exe
	docs
		syntax.md
	tools(Not yet fully perfected.)
	examples
	runtime
	script
	scr
		codegen.cpp
		runner.cpp
		runner.h
		pry_commom.h
		parser.cpp
		main.cpp
		lexer.cpp
ALL:12.1MB
7.login
你的代码 (.pn)
        │
        ▼
  ┌──────────────┐   
  │  pryany 内核  │   词法/语法分析
  └──────────────┘
        │  翻译
        ▼
       cpp
        │  运行
        ▼
       g++

8.Last modified date:2026.10.26
9.program compiled date:2026.10.26