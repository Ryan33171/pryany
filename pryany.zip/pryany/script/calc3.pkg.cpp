#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <sstream>
#include <iostream>

#ifdef _WIN32
#include <windows.h>
#endif

namespace pry {
    struct Val {
        long long n;
        std::string s;
        bool is_num;
        Val() : n(0), is_num(true) {}
        Val(long long v) : n(v), is_num(true) {}
        Val(const char* v) : s(v ? v : ""), is_num(false) {}
        Val(const std::string& v) : s(v), is_num(false) {}
    };

    static void print(const Val& v) {
        if (v.is_num) std::printf("%lld\n", v.n);
        else std::printf("%s\n", v.s.c_str());
    }
}

static void trim(std::string& s) {
    size_t i = 0, j = s.size();
    while (i < j && (s[i] == ' ' || s[i] == '\t')) i++;
    while (j > i && (s[j - 1] == ' ' || s[j - 1] == '\t')) j--;
    s = s.substr(i, j - i);
}

static void splitCall(const std::string& call,
                      std::string& fn,
                      std::vector<std::string>& args) {
    fn.clear();
    args.clear();

    size_t p = call.find('(');
    if (p == std::string::npos) {
        fn = call;
        trim(fn);
        return;
    }
    fn = call.substr(0, p);
    trim(fn);

    size_t q = call.rfind(')');
    if (q == std::string::npos || q <= p) return;
    std::string inner = call.substr(p + 1, q - p - 1);

    std::string cur;
    int depth = 0;
    bool in_str = false;

    for (char c : inner) {
        if (in_str) {
            cur += c;
            if (c == '"') in_str = false;
            continue;
        }
        if (c == '"') {
            in_str = true;
            cur += c;
            continue;
        }
        if (c == '(' || c == '[') { depth++; cur += c; continue; }
        if (c == ')' || c == ']') { depth--; cur += c; continue; }
        if (c == ',' && depth == 0) {
            trim(cur);
            args.push_back(cur);
            cur.clear();
        } else {
            cur += c;
        }
    }
    trim(cur);
    if (!cur.empty()) args.push_back(cur);
}

static void execCall(const std::string& fn, const std::vector<std::string>& args) {
    if (fn == "count") {
        long long n = args.empty() ? 0 : std::atoll(args[0].c_str());
        for (long long i = 1; i <= n; ++i) pry::print(pry::Val(i));
    } else if (fn == "echo") {
        std::string s = args.empty() ? "" : args[0];
        if (s.size() >= 2 && s.front() == '"' && s.back() == '"')
            s = s.substr(1, s.size() - 2);
        pry::print(pry::Val(s));
    } else if (fn == "repeat") {
        std::string s = args.size() > 0 ? args[0] : "";
        long long n = args.size() > 1 ? std::atoll(args[1].c_str()) : 1;
        if (s.size() >= 2 && s.front() == '"' && s.back() == '"')
            s = s.substr(1, s.size() - 2);
        for (long long i = 0; i < n; ++i) pry::print(pry::Val(s));
    } else {
        std::fprintf(stderr, "unknown function: %s\n", fn.c_str());
    }
}

static std::string genCode(const std::string& fn,
                           const std::vector<std::string>& args) {
    std::ostringstream o;
    if (fn == "count") {
        std::string n = args.empty() ? "0" : args[0];
        o << "  { long long __n = (" << n << ");\n"
          << "    for (long long __i = 1; __i <= __n; ++__i)\n"
          << "      pry::print(pry::Val(__i));\n"
          << "  } return pry::Val(0);\n";
    } else if (fn == "echo") {
        std::string s = args.empty() ? "\"\"" : args[0];
        o << "  pry::print(pry::Val(" << s << "));\n"
          << "  return pry::Val(0);\n";
    } else if (fn == "repeat") {
        std::string s = args.size() > 0 ? args[0] : "\"\"";
        std::string n = args.size() > 1 ? args[1] : "1";
        o << "  { long long __n = (" << n << ");\n"
          << "    for (long long __i = 0; __i < __n; ++__i)\n"
          << "      pry::print(pry::Val(" << s << "));\n"
          << "  } return pry::Val(0);\n";
    } else {
        o << "  // unknown: " << fn << "\n  return pry::Val();\n";
    }
    return o.str();
}

int main(int argc, char** argv) {
#ifdef _WIN32
    SetConsoleOutputCP(65001);
#endif

    bool exec_mode = false;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--exec") == 0) {
            exec_mode = true;
            break;
        }
    }

    if (argc >= 2 && std::strcmp(argv[1], "--info") == 0) {
        std::printf("count(n)\n");
        std::printf("echo(s)\n");
        std::printf("repeat(s, n)\n");
        return 0;
    }

    if (argc >= 3 && std::strcmp(argv[1], "--call") == 0) {
        std::string call = argv[2];
        std::string fn;
        std::vector<std::string> args;
        splitCall(call, fn, args);

        if (exec_mode) {
            execCall(fn, args);
            return 0;
        }
        std::printf("%s", genCode(fn, args).c_str());
        return 0;
    }

    if (argc >= 3 && std::strcmp(argv[1], "--call-file") == 0) {
        std::string call;
        FILE* f = std::fopen(argv[2], "rb");
        if (!f) {
            std::fprintf(stderr, "cannot open %s\n", argv[2]);
            return 1;
        }
        char buf[4096];
        size_t n;
        while ((n = std::fread(buf, 1, sizeof(buf), f)) > 0)
            call.append(buf, n);
        std::fclose(f);

        trim(call);
        std::string fn;
        std::vector<std::string> args;
        splitCall(call, fn, args);

        if (exec_mode) {
            execCall(fn, args);
            return 0;
        }
        std::printf("%s", genCode(fn, args).c_str());
        return 0;
    }

    std::fprintf(stderr,
        "usage: calc2.exe --info\n"
        "       calc2.exe --call \"fn(args)\" [--exec]\n"
        "       calc2.exe --call-file <file> [--exec]\n");
    return 1;
}
