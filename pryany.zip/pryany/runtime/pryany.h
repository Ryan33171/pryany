// ============================================================
//  pryany runtime  --  pryany ���Եĵײ�֧�ſ�
//  pryany Դ�뱻����� C++ ��#include ��ͷ�ļ������� g++
//  ���ļ������˶�ֵ̬���� Val����������塢���ú������ڴ����
// ============================================================
#ifndef PRYANY_RUNTIME_H
#define PRYANY_RUNTIME_H

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace pry {

struct Val;
using List = std::vector<Val>;

[[noreturn]] inline void pry_err(const std::string &msg) {
    throw std::runtime_error(msg);
}

// ------------------------------------------------------------
//  Val : pryany �Ķ�ֵ̬��Ĭ�ϱ������ͣ�
// ------------------------------------------------------------
struct Val {
    enum Kind { NUL = 0, INT, FLT, STR, BLN, LST, PTR } k = NUL;
    long long i = 0;
    double d = 0;
    bool b = false;
    void *p = nullptr;
    std::string s;
    List l;

    Val() {}
    Val(long long v) : k(INT), i(v) {}
    Val(int v) : k(INT), i(v) {}
    Val(double v) : k(FLT), d(v) {}
    Val(bool v) : k(BLN), b(v) {}
    Val(const char *v) : k(STR), s(v ? v : "") {}
    Val(const std::string &v) : k(STR), s(v) {}
    Val(void *v) : k(PTR), p(v) {}
    Val(const List &v) : k(LST), l(v) {}

    bool isNum() const { return k == INT || k == FLT || k == BLN; }

    double num() const {
        switch (k) {
        case INT: return (double)i;
        case FLT: return d;
        case BLN: return b ? 1.0 : 0.0;
        case STR: {
            try { return std::stod(s); } catch (...) { return 0.0; }
        }
        default: pry_err("���ܰ� " + typeName() + " ��������ʹ��");
        }
    }

    long long asInt() const {
        switch (k) {
        case INT: return i;
        case FLT: return (long long)d;
        case BLN: return b ? 1 : 0;
        case PTR: return (long long)(std::intptr_t)p;
        case STR: {
            try { return std::stoll(s); } catch (...) { return 0; }
        }
        default: pry_err("���ܰ� " + typeName() + " ת��Ϊ����");
        }
    }

    double asFlt() const { return num(); }

    std::string asStr() const {
        switch (k) {
        case STR: return s;
        case INT: return std::to_string(i);
        case FLT: return fmtDouble(d);
        case BLN: return b ? "true" : "false";
        case NUL: return "nil";
        case PTR: return fmtPtr(p);
        case LST: {
            std::string r = "[";
            for (size_t j = 0; j < l.size(); j++) {
                if (j) r += ", ";
                r += l[j].asStr();
            }
            return r + "]";
        }
        }
        return "";
    }

    bool asBool() const { return truthy(); }

    void *ptr() const {
        if (k == PTR) return p;
        if (k == INT) return (void *)(std::intptr_t)i;  // ��������������ַ��
        if (k == NUL) return nullptr;
        pry_err("���ܰ� " + typeName() + " ����ָ��ʹ��");
    }

    bool truthy() const {
        switch (k) {
        case NUL: return false;
        case INT: return i != 0;
        case FLT: return d != 0.0;
        case BLN: return b;
        case STR: return !s.empty();
        case LST: return !l.empty();
        case PTR: return p != nullptr;
        }
        return false;
    }

    static std::string fmtDouble(double v) {
        if (v == std::floor(v) && std::fabs(v) < 1e15) {
            std::ostringstream o;
            o << (long long)v << ".0";
            return o.str();
        }
        std::ostringstream o;
        o << v;
        return o.str();
    }

    static std::string fmtPtr(void *p) {
        std::ostringstream o;
        o << "0x" << std::hex << (std::uintptr_t)p;
        return o.str();
    }

    std::string typeName() const {
        switch (k) {
        case NUL: return "nil";
        case INT: return "int";
        case FLT: return "float";
        case STR: return "str";
        case BLN: return "bool";
        case LST: return "list";
        case PTR: return "ptr";
        }
        return "?";
    }

    // ���� / ��ƬԪ��
    Val &at(long long idx) {
        long long n = (long long)l.size();
        if (idx < 0) idx += n;
        if (k == STR) {
            long long m = (long long)s.size();
            if (idx < 0) idx += m;
            if (idx < 0 || idx >= m) pry_err("�ַ����±�Խ��: " + std::to_string(idx));
            static thread_local Val tmp;
            tmp = Val(std::string(1, s[(size_t)idx]));
            return tmp;
        }
        if (k == PTR) {  // ��ָ̬�룺�� 8 �ֽ�Ԫ�ط��ʣ��� new int һ�£�
            if (!p) pry_err("��ָ�벻���±����");
            if (idx < 0) pry_err("ָ���±겻��Ϊ����: " + std::to_string(idx));
            static thread_local Val tmp;
            tmp = Val((long long)((long long *)p)[(size_t)idx]);
            return tmp;
        }
        if (k != LST) pry_err("���� " + typeName() + " ��֧���±����");
        if (idx < 0 || idx >= n) pry_err("�±�Խ��: " + std::to_string(idx));
        return l[(size_t)idx];
    }

    Val get(const Val &idx) const { return ((Val *)this)->at(idx.asInt()); }

    void set(const Val &idx, const Val &v) {
        if (k == PTR) {  // ��ָ̬�룺�� 8 �ֽ�Ԫ��д
            if (!p) pry_err("��ָ�벻���±긳ֵ");
            long long j = idx.asInt();
            if (j < 0) pry_err("ָ���±겻��Ϊ����: " + std::to_string(j));
            ((long long *)p)[(size_t)j] = v.asInt();
            return;
        }
        if (k != LST) pry_err("���� " + typeName() + " ��֧���±긳ֵ");
        long long n = (long long)l.size();
        long long j = idx.asInt();
        if (j < 0) j += n;
        if (j < 0 || j >= n) pry_err("�±�Խ��: " + std::to_string(j));
        l[(size_t)j] = v;
    }

    Val &operator[](const Val &idx) { return at(idx.asInt()); }
};

// ------------------------------------------------------------
//  �����
// ------------------------------------------------------------
inline bool valEq(const Val &a, const Val &b) {
    if (a.k == Val::NUL && b.k == Val::NUL) return true;
    if (a.k == Val::NUL || b.k == Val::NUL) return false;
    if (a.k == Val::STR || b.k == Val::STR) return a.asStr() == b.asStr();
    if (a.k == Val::PTR || b.k == Val::PTR) return a.ptr() == b.ptr();
    if (a.k == Val::LST || b.k == Val::LST) {
        if (a.k != b.k || a.l.size() != b.l.size()) return false;
        for (size_t j = 0; j < a.l.size(); j++)
            if (!valEq(a.l[j], b.l[j])) return false;
        return true;
    }
    return a.num() == b.num();
}

inline Val operator+(const Val &a, const Val &b) {
    if (a.k == Val::STR || b.k == Val::STR) return Val(a.asStr() + b.asStr());
    if (a.k == Val::LST && b.k == Val::LST) {
        List r = a.l;
        r.insert(r.end(), b.l.begin(), b.l.end());
        return Val(r);
    }
    if (a.k == Val::FLT || b.k == Val::FLT) return Val(a.num() + b.num());
    return Val(a.asInt() + b.asInt());
}

inline Val operator-(const Val &a, const Val &b) {
    if (a.k == Val::FLT || b.k == Val::FLT) return Val(a.num() - b.num());
    return Val(a.asInt() - b.asInt());
}

inline Val operator*(const Val &a, const Val &b) {
    if (a.k == Val::STR && b.k == Val::INT) {
        std::string r;
        for (long long j = 0; j < b.i; j++) r += a.s;
        return Val(r);
    }
    if (b.k == Val::STR && a.k == Val::INT) {
        std::string r;
        for (long long j = 0; j < a.i; j++) r += b.s;
        return Val(r);
    }
    if (a.k == Val::FLT || b.k == Val::FLT) return Val(a.num() * b.num());
    return Val(a.asInt() * b.asInt());
}

inline Val operator/(const Val &a, const Val &b) {
    double y = b.num();
    if (y == 0) pry_err("�������");
    return Val(a.num() / y);
}

inline Val idiv(const Val &a, const Val &b) {
    long long y = b.asInt();
    if (y == 0) pry_err("���������");
    return Val(a.asInt() / y);
}

inline Val operator%(const Val &a, const Val &b) {
    if (a.k == Val::FLT || b.k == Val::FLT) {
        double y = b.num();
        if (y == 0) pry_err("ȡģ�����");
        return Val(std::fmod(a.num(), y));
    }
    long long y = b.asInt();
    if (y == 0) pry_err("ȡģ�����");
    return Val(a.asInt() % y);
}

inline Val power(const Val &a, const Val &b) { return Val(std::pow(a.num(), b.num())); }

inline Val operator-(const Val &a) {
    if (a.k == Val::FLT) return Val(-a.d);
    return Val(-a.asInt());
}

inline bool operator<(const Val &a, const Val &b) {
    if (a.k == Val::STR && b.k == Val::STR) return a.s < b.s;
    return a.num() < b.num();
}
inline bool operator>(const Val &a, const Val &b) { return b < a; }
inline bool operator<=(const Val &a, const Val &b) { return !(b < a); }
inline bool operator>=(const Val &a, const Val &b) { return !(a < b); }
inline bool operator==(const Val &a, const Val &b) { return valEq(a, b); }
inline bool operator!=(const Val &a, const Val &b) { return !valEq(a, b); }

inline bool truthy(const Val &a) { return a.truthy(); }

inline std::ostream &operator<<(std::ostream &o, const Val &v) {
    switch (v.k) {
    case Val::STR: return o << v.s;
    case Val::FLT: return o << Val::fmtDouble(v.d);
    case Val::INT: return o << v.i;
    case Val::BLN: return o << (v.b ? "true" : "false");
    case Val::NUL: return o << "nil";
    case Val::PTR: return o << Val::fmtPtr(v.p);
    case Val::LST: return o << v.asStr();
    }
    return o;
}

// ------------------------------------------------------------
//  ���
// ------------------------------------------------------------
inline void printImpl(std::ostream &o) {}

template <class A, class... R>
inline void printImpl(std::ostream &o, const A &a, const R &...r) {
    o << a;
    if (sizeof...(r)) o << " ";
    printImpl(o, r...);
}

template <class... T>
inline void print(const T &...a) {
    std::ostringstream o;
    printImpl(o, a...);
    o << "\n";
    std::cout << o.str();
    std::cout.flush();
}

// ------------------------------------------------------------
//  ���ú���
// ------------------------------------------------------------
inline Val len(const Val &v) {
    if (v.k == Val::STR) return Val((long long)v.s.size());
    if (v.k == Val::LST) return Val((long long)v.l.size());
    pry_err("len() ��Ҫ�ַ������б�");
}

// ע�⣺push / pop / sort / reverse ֱ���޸�ԭ�������� Python ϰ��һ�£�
inline Val &push(Val &v, const Val &x) {
    if (v.k == Val::NUL) { v = Val(List{}); }
    if (v.k != Val::LST) pry_err("push() ��Ҫ�б�");
    v.l.push_back(x);
    return v;
}

inline Val pop(Val &v) {
    if (v.k != Val::LST || v.l.empty()) pry_err("pop() ��Ҫ�ǿ��б�");
    Val r = v.l.back();
    v.l.pop_back();
    return r;
}

inline Val tostr(const Val &v) { return Val(v.asStr()); }
inline Val toint(const Val &v) { return Val(v.asInt()); }
inline Val toflt(const Val &v) { return Val(v.num()); }
inline Val tobool(const Val &v) { return Val(v.truthy()); }
inline Val type(const Val &v) { return Val(v.typeName()); }

inline Val abs_(const Val &v) {
    if (v.k == Val::FLT) return Val(std::fabs(v.d));
    return Val(v.asInt() < 0 ? -v.asInt() : v.asInt());
}
inline Val min_(const Val &a, const Val &b) { return (b < a) ? b : a; }
inline Val max_(const Val &a, const Val &b) { return (a < b) ? b : a; }
inline Val sqrt_(const Val &a) { return Val(std::sqrt(a.num())); }
inline Val pow_(const Val &a, const Val &b) { return Val(std::pow(a.num(), b.num())); }
inline Val floor_(const Val &a) { return Val((long long)std::floor(a.num())); }
inline Val ceil_(const Val &a) { return Val((long long)std::ceil(a.num())); }
inline Val sin_(const Val &a) { return Val(std::sin(a.num())); }
inline Val cos_(const Val &a) { return Val(std::cos(a.num())); }

inline long long now_ms() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
               std::chrono::steady_clock::now().time_since_epoch())
        .count();
}
inline Val time_() { return Val(now_ms()); }
inline Val time_(const Val &) { return Val(now_ms()); }
inline Val sleep_() { return Val(); }
inline Val sleep_(const Val &ms) {
    std::this_thread::sleep_for(std::chrono::milliseconds(ms.asInt()));
    return Val();
}
inline Val rand_(const Val &a, const Val &b);  // ǰ������
inline Val rand_() { return rand_(Val(0LL), Val((long long)RAND_MAX)); }
inline Val rand_(const Val &a, const Val &b) {
    static std::mt19937_64 gen(std::random_device{}());
    long long lo = a.asInt(), hi = b.asInt();
    if (hi < lo) std::swap(lo, hi);
    std::uniform_int_distribution<long long> dist(lo, hi);
    return Val(dist(gen));
}
[[noreturn]] inline void exit_() { std::exit(0); }
[[noreturn]] inline void exit_(const Val &code) { std::exit((int)code.asInt()); }

inline Val range_(const Val &a, const Val &b, const Val &c);  // ǰ������
inline Val range_(const Val &a) { return range_(Val(0LL), a, Val()); }
inline Val range_(const Val &a, const Val &b) { return range_(a, b, Val()); }
inline Val range_(const Val &a, const Val &b, const Val &c) {
    long long lo = a.asInt(), hi = b.asInt();
    long long step = c.k == Val::NUL ? 1 : c.asInt();
    if (step == 0) pry_err("range() ��������Ϊ 0");
    List r;
    for (long long j = lo; step > 0 ? j < hi : j > hi; j += step) r.push_back(Val(j));
    return Val(r);
}

inline Val input_(const Val &prompt);  // ǰ������
inline Val input_() { return input_(Val(std::string(""))); }
inline Val input_(const Val &prompt) {
    std::string p = prompt.asStr();
    if (p.size() && p.back() != ' ' && p.back() != '\t') p += " ";  // ���ظ��ӿո�
    std::cout << p;
    std::cout.flush();
    std::string line;
    if (!std::getline(std::cin, line)) return Val(std::string(""));
    if (!line.empty() && line.back() == '\r') line.pop_back();
    return Val(line);
}

// �ַ�������
inline Val upper(const Val &v) {
    std::string r = v.asStr();
    for (auto &ch : r) ch = (char)std::toupper((unsigned char)ch);
    return Val(r);
}
inline Val lower(const Val &v) {
    std::string r = v.asStr();
    for (auto &ch : r) ch = (char)std::tolower((unsigned char)ch);
    return Val(r);
}
inline std::string trimStr(const std::string &in) {
    size_t a = 0, b = in.size();
    while (a < b && std::isspace((unsigned char)in[a])) a++;
    while (b > a && std::isspace((unsigned char)in[b - 1])) b--;
    return in.substr(a, b - a);
}
inline Val trim(const Val &v) { return Val(trimStr(v.asStr())); }
inline Val split(const Val &s, const Val &sep) {
    std::string src = s.asStr();
    std::string d = sep.asStr();
    if (d.empty()) d = " ";
    List r;
    size_t pos = 0;
    while (true) {
        size_t nxt = src.find(d, pos);
        if (nxt == std::string::npos) {
            r.push_back(Val(src.substr(pos)));
            break;
        }
        r.push_back(Val(src.substr(pos, nxt - pos)));
        pos = nxt + d.size();
    }
    return Val(r);
}
inline Val join(const Val &lst, const Val &sep) {
    if (lst.k != Val::LST) pry_err("join() ��Ҫ�б�");
    std::string d = sep.asStr(), r;
    for (size_t j = 0; j < lst.l.size(); j++) {
        if (j) r += d;
        r += lst.l[j].asStr();
    }
    return Val(r);
}
inline Val contains(const Val &hay, const Val &needle) {
    if (hay.k == Val::LST) {
        for (auto &x : hay.l)
            if (valEq(x, needle)) return Val(true);
        return Val(false);
    }
    return Val(hay.asStr().find(needle.asStr()) != std::string::npos);
}
inline Val &reverse_(Val &v) {
    if (v.k == Val::LST) std::reverse(v.l.begin(), v.l.end());
    else {
        std::string r = v.asStr();
        std::reverse(r.begin(), r.end());
        v = Val(r);
    }
    return v;
}
inline Val &sort_(Val &v) {
    if (v.k != Val::LST) pry_err("sort() ��Ҫ�б�");
    std::sort(v.l.begin(), v.l.end(), [](const Val &a, const Val &b) { return a < b; });
    return v;
}
inline Val slice(const Val &v, const Val &a, const Val &b) {
    std::string s = v.asStr();
    long long n = (long long)s.size();
    long long i = a.asInt();
    if (i < 0) i += n;
    long long j = b.k == Val::NUL ? n : b.asInt();
    if (j < 0) j += n;
    i = std::max(0LL, std::min(i, n));
    j = std::max(0LL, std::min(j, n));
    if (j < i) j = i;
    return Val(s.substr((size_t)i, (size_t)(j - i)));
}

// REPL �ط���ʷ���ʱʹ�õľ�Ĭ��������ظ���ӡ��
template <class... T>
inline void silent(const T &...) {}

// ------------------------------------------------------------
//  �ڴ������pryany �ĵײ�����
// ------------------------------------------------------------
inline Val alloc(const Val &n) {  // ���� n �ֽڶ��ڴ�
    long long sz = n.asInt();
    if (sz <= 0) pry_err("alloc() ��С����Ϊ������");
    void *p = std::calloc((size_t)sz, 1);
    if (!p) pry_err("alloc() �ڴ����ʧ��");
    return Val(p);
}
inline Val freep(const Val &p) {
    void *q = p.ptr();
    if (q) std::free(q);
    return Val();
}
inline unsigned char *base(const Val &p) { return (unsigned char *)p.ptr(); }
inline Val peek(const Val &p, const Val &off) {  // �� 1 �ֽ�
    return Val((long long)base(p)[off.asInt()]);
}
inline Val poke(const Val &p, const Val &off, const Val &v) {  // д 1 �ֽ�
    base(p)[off.asInt()] = (unsigned char)(v.asInt() & 0xff);
    return Val();
}
inline Val peek4(const Val &p, const Val &off) {  // �� 4 �ֽ�С��
    unsigned char *q = base(p) + off.asInt();
    unsigned int r = 0;
    std::memcpy(&r, q, 4);
    return Val((long long)r);
}
inline Val poke4(const Val &p, const Val &off, const Val &v) {
    unsigned char *q = base(p) + off.asInt();
    unsigned int x = (unsigned int)(v.asInt() & 0xffffffffu);
    std::memcpy(q, &x, 4);
    return Val();
}
inline Val peek8(const Val &p, const Val &off) {  // �� 8 �ֽ�
    unsigned char *q = base(p) + off.asInt();
    long long r = 0;
    std::memcpy(&r, q, 8);
    return Val(r);
}
inline Val poke8(const Val &p, const Val &off, const Val &v) {
    unsigned char *q = base(p) + off.asInt();
    long long x = v.asInt();
    std::memcpy(q, &x, 8);
    return Val();
}
inline Val memfill(const Val &p, const Val &v, const Val &n) {  // memset
    std::memset(base(p), (int)(v.asInt() & 0xff), (size_t)n.asInt());
    return Val();
}
inline Val memcopy(const Val &dst, const Val &src, const Val &n) {  // memcpy
    std::memcpy(base(dst), base(src), (size_t)n.asInt());
    return Val();
}
inline Val memcmp_(const Val &a, const Val &b, const Val &n) {
    return Val((long long)std::memcmp(base(a), base(b), (size_t)n.asInt()));
}
inline Val addr(const Val &n) {  // ���������ɵ�ַ
    return Val((void *)(std::intptr_t)n.asInt());
}
inline Val toptr(const Val &p) {  // ָ�� -> ����
    return Val((long long)(std::intptr_t)p.ptr());
}
inline Val dumphex(const Val &p, const Val &n) {  // ʮ������ת��
    unsigned char *q = base(p);
    long long cnt = n.asInt();
    std::string r;
    char buf[16];
    for (long long j = 0; j < cnt; j++) {
        if (j && j % 16 == 0) r += "\n";
        std::snprintf(buf, sizeof(buf), "%02x ", q[j]);
        r += buf;
    }
    return Val(r);
}

// ����֧�֣�for x in <ֵ>
inline List iterable(const Val &v) {
    if (v.k == Val::LST) return v.l;
    if (v.k == Val::STR) {
        List r;
        for (char c : v.s) r.push_back(Val(std::string(1, c)));
        return r;
    }
    pry_err("���ܵ��� " + v.typeName() + "����Ҫ�б����ַ���");
}

}  // namespace pry

#endif
