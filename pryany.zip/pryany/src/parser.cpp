// pryany �﷨���������ݹ��½���
#include "pry_common.h"
#include <set>

static const std::set<std::string> kTypeWords = {"int", "float", "str", "bool", "ptr", "raw", "any"};

static std::string mapType(const std::string &base, int stars) {
    std::string c;
    if (base == "int") c = "long long";
    else if (base == "float") c = "double";
    else if (base == "str") c = "std::string";
    else if (base == "bool") c = "bool";
    else if (base == "ptr") c = "void*";
    else if (base == "raw") c = "unsigned char";
    else if (base == "any") c = "pry::Val";
    else c = base;
    for (int j = 0; j < stars; j++) c += "*";
    return c;
}

struct Parser {
    const std::vector<Token> &t;
    size_t i = 0;
    explicit Parser(const std::vector<Token> &toks) : t(toks) {}

    const Token &cur() const { return t[i]; }
    const Token &peek(int n = 1) const {
        size_t j = i + (size_t)n;
        return j < t.size() ? t[j] : t.back();
    }
    bool isEnd() const { return cur().type == Tok::End; }
    bool isOp(const char *s) const { return cur().type == Tok::Op && cur().text == s; }
    bool isKey(const char *s) const { return cur().type == Tok::Key && cur().text == s; }
    bool isIdent() const { return cur().type == Tok::Ident; }

    void skipNl() {
        while (cur().type == Tok::Newline) i++;
    }
    void expectOp(const char *s) {
        if (!isOp(s)) pryFail(std::string("���� '") + s + "'��ȴ���� '" + cur().text + "'", cur().line);
        i++;
    }
    std::string expectIdent() {
        if (cur().type != Tok::Ident)
            pryFail("������ʶ����ȴ���� '" + cur().text + "'", cur().line);
        return t[i++].text;
    }
    void blockEnd() {  // ����䣨if/while/for/fn��������������һ�����У�������ǿ��Ҫ��
        if (cur().type == Tok::Newline) i++;
    }

    void endStmt() {
        if (cur().type == Tok::Newline) { i++; return; }
        if (cur().type == Tok::End || isOp("}")) return;
        pryFail("���δ��ȷ���������� '" + cur().text + "'���Ƿ����˻��л�ֺţ���", cur().line);
    }

    // ---------- ����ʽ ----------
    ExprP parseExpr() { return parseOr(); }

    ExprP parseOr() {
        auto a = parseAnd();
        while (isKey("or")) {
            int ln = cur().line;
            i++;
            auto e = Expr::make(Expr::Bin, "or", ln);
            e->kids = {a, parseAnd()};
            a = e;
        }
        return a;
    }
    ExprP parseAnd() {
        auto a = parseBitor();
        while (isKey("and")) {
            int ln = cur().line;
            i++;
            auto e = Expr::make(Expr::Bin, "and", ln);
            e->kids = {a, parseBitor()};
            a = e;
        }
        return a;
    }
    ExprP parseBitor() {
        auto a = parseBitxor();
        while (isOp("|")) {
            int ln = cur().line;
            i++;
            auto e = Expr::make(Expr::Bin, "|", ln);
            e->kids = {a, parseBitxor()};
            a = e;
        }
        return a;
    }
    ExprP parseBitxor() {
        auto a = parseBitand();
        while (isOp("^")) {
            int ln = cur().line;
            i++;
            auto e = Expr::make(Expr::Bin, "^", ln);
            e->kids = {a, parseBitand()};
            a = e;
        }
        return a;
    }
    ExprP parseBitand() {
        auto a = parseEq();
        while (isOp("&")) {
            int ln = cur().line;
            i++;
            auto e = Expr::make(Expr::Bin, "&", ln);
            e->kids = {a, parseEq()};
            a = e;
        }
        return a;
    }
    ExprP parseEq() {
        auto a = parseCmp();
        while (isOp("==") || isOp("!=")) {
            int ln = cur().line;
            std::string op = cur().text;
            i++;
            auto e = Expr::make(Expr::Bin, op, ln);
            e->kids = {a, parseCmp()};
            a = e;
        }
        return a;
    }
    ExprP parseCmp() {
        auto a = parseShift();
        while (isOp("<") || isOp(">") || isOp("<=") || isOp(">=")) {
            int ln = cur().line;
            std::string op = cur().text;
            i++;
            auto e = Expr::make(Expr::Bin, op, ln);
            e->kids = {a, parseShift()};
            a = e;
        }
        return a;
    }
    ExprP parseShift() {
        auto a = parseAdd();
        while (isOp("<<") || isOp(">>")) {
            int ln = cur().line;
            std::string op = cur().text;
            i++;
            auto e = Expr::make(Expr::Bin, op, ln);
            e->kids = {a, parseAdd()};
            a = e;
        }
        return a;
    }
    ExprP parseAdd() {
        auto a = parseMul();
        while (isOp("+") || isOp("-")) {
            int ln = cur().line;
            std::string op = cur().text;
            i++;
            auto e = Expr::make(Expr::Bin, op, ln);
            e->kids = {a, parseMul()};
            a = e;
        }
        return a;
    }
    ExprP parseMul() {
        auto a = parseUnary();
        while (isOp("*") || isOp("/") || isOp("//") || isOp("%")) {
            int ln = cur().line;
            std::string op = cur().text;
            i++;
            auto e = Expr::make(Expr::Bin, op, ln);
            e->kids = {a, parseUnary()};
            a = e;
        }
        return a;
    }
    ExprP parseUnary() {
        int ln = cur().line;
        if (isOp("-")) {
            i++;
            auto e = Expr::make(Expr::Un, "-", ln);
            e->kids = {parseUnary()};
            return e;
        }
        if (isOp("+")) {
            i++;
            return parseUnary();
        }
        if (isKey("not")) {
            i++;
            auto e = Expr::make(Expr::Un, "not", ln);
            e->kids = {parseUnary()};
            return e;
        }
        if (isOp("~")) {
            i++;
            auto e = Expr::make(Expr::Un, "~", ln);
            e->kids = {parseUnary()};
            return e;
        }
        if (isOp("&")) {  // ȡ��ַ
            i++;
            auto e = Expr::make(Expr::Un, "&", ln);
            e->kids = {parseUnary()};
            return e;
        }
        if (isOp("*")) {  // ������
            i++;
            auto e = Expr::make(Expr::Un, "*", ln);
            e->kids = {parseUnary()};
            return e;
        }
        return parsePow();
    }
    ExprP parsePow() {
        auto a = parsePostfix();
        if (isOp("**")) {
            int ln = cur().line;
            i++;
            auto e = Expr::make(Expr::Bin, "**", ln);
            e->kids = {a, parseUnary()};  // �ҽ��
            return e;
        }
        return a;
    }
    ExprP parsePostfix() {
        auto a = parsePrimary();
        while (true) {
            if (isOp("[")) {
                int ln = cur().line;
                i++;
                auto e = Expr::make(Expr::Index, "", ln);
                e->kids = {a, parseExpr()};
                expectOp("]");
                a = e;
            } else if (isOp("(")) {
                int ln = cur().line;
                i++;
                auto e = Expr::make(Expr::Call, "", ln);
                e->kids.push_back(a);
                if (!isOp(")")) {
                    e->kids.push_back(parseExpr());
                    while (isOp(",")) {
                        i++;
                        e->kids.push_back(parseExpr());
                    }
                }
                expectOp(")");
                a = e;
            } else if (isOp(".")) {
                int ln = cur().line;
                i++;
                std::string name = expectIdent();
                auto e = Expr::make(Expr::Member, name, ln);
                e->kids.push_back(a);
                if (isOp("(")) {
                    i++;
                    if (!isOp(")")) {
                        e->kids.push_back(parseExpr());
                        while (isOp(",")) {
                            i++;
                            e->kids.push_back(parseExpr());
                        }
                    }
                    expectOp(")");
                }
                a = e;
            } else {
                break;
            }
        }
        return a;
    }
    ExprP parseTypeCall() {  // int(x) / float(x) / str(x) / bool(x)
        int ln = cur().line;
        std::string name = cur().text;
        i++;  // ����������
        expectOp("(");
        auto e = Expr::make(Expr::Call, "", ln);
        e->kids.push_back(Expr::make(Expr::Var, name, ln));
        if (!isOp(")")) {
            e->kids.push_back(parseExpr());
            while (isOp(",")) {
                i++;
                e->kids.push_back(parseExpr());
            }
        }
        expectOp(")");
        return e;
    }

    ExprP parsePrimary() {
        int ln = cur().line;
        if (cur().type == Tok::Key && kTypeWords.count(cur().text) && peek().type == Tok::Op &&
            peek().text == "(")
            return parseTypeCall();
        if (cur().type == Tok::Num) {
            auto e = Expr::make(Expr::Num, cur().text, ln);
            i++;
            return e;
        }
        if (cur().type == Tok::Str) {
            auto e = Expr::make(Expr::Str, cur().text, ln);
            i++;
            return e;
        }
        if (isKey("true") || isKey("false")) {
            auto e = Expr::make(Expr::Bool, cur().text, ln);
            e->bval = (cur().text == "true");
            i++;
            return e;
        }
        if (isKey("nil")) {
            i++;
            return Expr::make(Expr::Nil, "", ln);
        }
        if (isKey("new")) {  // new int / new int [n]
            i++;
            if (cur().type != Tok::Key || !kTypeWords.count(cur().text))
                pryFail("new ������Ҫ���ͣ�int/float/str/bool/ptr/raw��", ln);
            std::string base = cur().text;
            i++;
            int stars = 0;
            while (isOp("*")) { i++; stars++; }
            auto e = Expr::make(Expr::NewE, mapType(base, stars), ln);
            if (isOp("[")) {
                i++;
                e->kids.push_back(parseExpr());
                expectOp("]");
            }
            return e;
        }
        if (isKey("sizeof")) {
            i++;
            expectOp("(");
            if (cur().type != Tok::Key || !kTypeWords.count(cur().text))
                pryFail("sizeof() ��Ҫ������", cur().line);
            std::string base = cur().text;
            i++;
            int stars = 0;
            while (isOp("*")) { i++; stars++; }
            expectOp(")");
            return Expr::make(Expr::SizeofE, mapType(base, stars), ln);
        }
        if (isKey("pku") || isKey("pk")) {  // pku.����.���� / pk.����.����
            i++;
            expectOp(".");
            std::string pkg = expectIdent();
            if (!isOp("."))
                pryFail("pku ����д����pku.����.������(...)", ln);
            i++;
            std::string fn = expectIdent();
            auto e = Expr::make(Expr::PkuCall, pkg + "." + fn, ln);
            if (isOp("(")) {
                i++;
                if (!isOp(")")) {
                    e->kids.push_back(parseExpr());
                    while (isOp(",")) {
                        i++;
                        e->kids.push_back(parseExpr());
                    }
                }
                expectOp(")");
            }
            return e;
        }
        if (cur().type == Tok::Raw) {  // ���� C++ ����ʽ
            auto e = Expr::make(Expr::RawCpp, cur().text, ln);
            i++;
            return e;
        }
        if (isOp("(")) {
            i++;
            auto e = parseExpr();
            expectOp(")");
            return e;
        }
        if (isOp("[")) {  // �б�
            i++;
            auto e = Expr::make(Expr::ListE, "", ln);
            if (!isOp("]")) {
                e->kids.push_back(parseExpr());
                while (isOp(",")) {
                    i++;
                    e->kids.push_back(parseExpr());
                }
            }
            expectOp("]");
            return e;
        }
        if (cur().type == Tok::Ident) {
            auto e = Expr::make(Expr::Var, cur().text, ln);
            i++;
            return e;
        }
        pryFail("����ķ��� '" + cur().text + "'", ln);
    }

    // ---------- ���� ----------
    bool tryType(std::string &out) {
        if (cur().type != Tok::Key || !kTypeWords.count(cur().text)) return false;
        std::string base = cur().text;
        // ������ "���� ��ʶ��" �� "���� * ��ʶ��"
        size_t save = i;
        i++;
        int stars = 0;
        while (isOp("*")) { i++; stars++; }
        if (cur().type != Tok::Ident) {
            i = save;
            return false;
        }
        out = mapType(base, stars);
        return true;
    }

    // ---------- �� ----------
    std::vector<StmtP> parseBlock() {
        expectOp("{");
        skipNl();
        std::vector<StmtP> body;
        while (!isOp("}")) {
            if (isEnd()) pryFail("�����û�бպϵ� '}'", cur().line);
            body.push_back(parseStmt());
            skipNl();
        }
        expectOp("}");
        return body;
    }

    // ---------- ��� ----------
    StmtP parseStmt() {
        int ln = cur().line;
        std::string decl;
        if (tryType(decl)) {  // ��������
            std::string name = expectIdent();
            auto s = Stmt::make(Stmt::Assign, ln);
            s->declType = decl;
            s->name = name;
            if (isOp("=")) {
                i++;
                s->e = parseExpr();
            } else {
                s->e = nullptr;
            }
            endStmt();
            return s;
        }
        if (isKey("say") || isKey("print")) {
            i++;
            auto s = Stmt::make(Stmt::Say, ln);
            if (!(cur().type == Tok::Newline || isEnd() || isOp("}"))) {
                s->exprs.push_back(parseExpr());
                while (isOp(",")) {
                    i++;
                    s->exprs.push_back(parseExpr());
                }
            }
            endStmt();
            return s;
        }
        if (isKey("ask")) {
            i++;
            auto s = Stmt::make(Stmt::Ask, ln);
            // ask -> name��û����ʾ���ask "��ʾ" -> name��ask ����ʽ
            if (!(cur().type == Tok::Newline || isEnd() || isOp("}") || isOp("->")))
                s->e = parseExpr();
            if (isOp("->")) {
                i++;
                s->name = expectIdent();
            }
            endStmt();
            return s;
        }
        if (isKey("use")) {
            i++;
            if (cur().type != Tok::Str) pryFail("use ������Ҫ�ַ���·������ use \"lib.pn\"", cur().line);
            auto s = Stmt::make(Stmt::Use, ln);
            s->name = cur().text;
            i++;
            endStmt();
            return s;
        }
        if (isKey("pkuip")) {  // pkuip ����
            i++;
            if (cur().type != Tok::Ident)
                pryFail("pkuip ������Ҫ�������� pkuip mathlib", cur().line);
            auto s = Stmt::make(Stmt::Pkuip, ln);
            s->name = cur().text;
            i++;
            endStmt();
            return s;
        }
        if (isKey("del")) {
            i++;
            auto s = Stmt::make(Stmt::Del, ln);
            s->e = parseExpr();
            endStmt();
            return s;
        }
        if (isKey("ret")) {
            i++;
            auto s = Stmt::make(Stmt::Ret, ln);
            if (!(cur().type == Tok::Newline || isEnd() || isOp("}"))) s->e = parseExpr();
            endStmt();
            return s;
        }
        if (isKey("break")) {
            i++;
            endStmt();
            return Stmt::make(Stmt::Break, ln);
        }
        if (isKey("continue")) {
            i++;
            endStmt();
            return Stmt::make(Stmt::Continue, ln);
        }
        if (isKey("if")) {
            i++;
            auto s = Stmt::make(Stmt::If, ln);
            Branch b;
            b.cond = parseExpr();
            b.body = parseBlock();
            s->branches.push_back(b);
            bool sawNl = false;
            if (cur().type == Tok::Newline) { i++; sawNl = true; }
            while (isKey("elif")) {
                i++;
                Branch eb;
                eb.cond = parseExpr();
                eb.body = parseBlock();
                s->branches.push_back(eb);
                if (cur().type == Tok::Newline) { i++; sawNl = true; }
            }
            if (isKey("else")) {
                i++;
                Branch eb;
                eb.cond = nullptr;
                eb.body = parseBlock();
                s->branches.push_back(eb);
                if (cur().type == Tok::Newline) { i++; sawNl = true; }
            }
            (void)sawNl;  // �����������ֱ�ӽ���һ�䣨ͬһ��Ҳ�У�
            return s;
        }
        if (isKey("while")) {
            i++;
            auto s = Stmt::make(Stmt::While, ln);
            s->e = parseExpr();
            s->body = parseBlock();
            blockEnd();
            return s;
        }
        if (isKey("for")) {
            i++;
            std::string var = expectIdent();
            if (isKey("in")) {  // for x in list
                i++;
                auto s = Stmt::make(Stmt::ForIn, ln);
                s->name = var;
                s->e = parseExpr();
                s->body = parseBlock();
                blockEnd();
                return s;
            }
            if (!isOp("=")) pryFail("for ѭ��д����for i = 0, 10 { }  ��  for x in list { }", cur().line);
            i++;
            auto s = Stmt::make(Stmt::ForNum, ln);
            s->name = var;
            s->exprs.push_back(parseExpr());
            expectOp(",");
            s->exprs.push_back(parseExpr());
            if (isOp(",")) {
                i++;
                s->exprs.push_back(parseExpr());
            }
            s->body = parseBlock();
            blockEnd();
            return s;
        }
        if (isKey("fn")) {  // fn name(a, b) { }
            i++;
            auto s = Stmt::make(Stmt::Fn, ln);
            s->name = expectIdent();
            expectOp("(");
            if (!isOp(")")) {
                while (true) {
                    std::string pt;
                    if (tryType(pt)) {
                        s->paramTypes.push_back(pt);
                        s->params.push_back(expectIdent());
                    } else {
                        s->paramTypes.push_back("");
                        s->params.push_back(expectIdent());
                    }
                    if (isOp(",")) { i++; continue; }
                    break;
                }
            }
            expectOp(")");
            if (isOp(":")) {  // fn f(): int
                i++;
                std::string rt;
                if (!tryTypeNoVar(rt)) pryFail("��������������Ҫ������", cur().line);
                s->retType = rt;
            }
            s->body = parseBlock();
            blockEnd();
            return s;
        }
        if (cur().type == Tok::Raw || cur().type == Tok::RawHead) {  // ���� C++ ����
            auto s = Stmt::make(Stmt::RawCpp, ln);
            s->name = cur().text;
            if (cur().type == Tok::RawHead) s->declType = "head";  // �ŵ������ļ�ͷ��
            i++;
            endStmt();
            return s;
        }
        // ��ֵ�����ʽ���
        auto e = parseExpr();
        if (isOp("=")) {
            i++;
            auto s = Stmt::make(Stmt::Assign, ln);
            s->e = e;                      // ��ֵ����ʽ
            s->exprs.push_back(parseExpr());  // ��ֵ
            endStmt();
            return s;
        }
        auto s = Stmt::make(Stmt::ExprS, ln);
        s->e = e;
        endStmt();
        return s;
    }

    bool tryTypeNoVar(std::string &out) {
        if (cur().type != Tok::Key || !kTypeWords.count(cur().text)) return false;
        std::string base = cur().text;
        i++;
        int stars = 0;
        while (isOp("*")) { i++; stars++; }
        out = mapType(base, stars);
        return true;
    }
};

std::vector<StmtP> parse(const std::vector<Token> &toks) {
    Parser p(toks);
    std::vector<StmtP> prog;
    p.skipNl();
    while (!p.isEnd()) {
        prog.push_back(p.parseStmt());
        p.skipNl();
    }
    return prog;
}
