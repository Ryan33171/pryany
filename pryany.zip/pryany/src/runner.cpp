// pryany ������ʵ��
#include "runner.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <cstring>
#include <sstream>

#ifdef _WIN32
#include <windows.h>
#else
#include <sys/wait.h>
#include <unistd.h>
#endif

std::string joinPath(const std::string &a, const std::string &b) {
    if (a.empty()) return b;
    if (a.back() == '/' || a.back() == '\\') return a + b;
    return a + "/" + b;
}

std::string exeDir() {
#ifdef _WIN32
    char buf[MAX_PATH];
    GetModuleFileNameA(nullptr, buf, MAX_PATH);
    return std::filesystem::path(buf).parent_path().string();
#else
    char buf[4096];
    ssize_t n = ::readlink("/proc/self/exe", buf, sizeof(buf) - 1);
    if (n <= 0) return ".";
    buf[n] = 0;
    return std::filesystem::path(buf).parent_path().string();
#endif
}

std::string findGpp() {
    const char *env = std::getenv("PRYANY_GPP");
    if (env && *env) return env;  // ��ʽָ�����ȣ��� set PRYANY_GPP=g++ ����ϵͳ��
    std::string cand = joinPath(exeDir(), "runtool/w64devkit/bin/g++.exe");
    if (std::filesystem::exists(cand)) return cand;  // ����� w64devkit
    return "g++";                                    // ���˵�ϵͳ PATH
}

std::string findRuntimeDir() {
    const char *env = std::getenv("PRYANY_HOME");
    std::vector<std::string> cands;
    if (env && *env) cands.push_back(joinPath(env, "runtime"));
    std::string ed = exeDir();
    cands.push_back(joinPath(std::filesystem::path(ed).parent_path().string(), "runtime"));
    cands.push_back(joinPath(ed, "runtime"));
    cands.push_back("/usr/local/share/pryany/runtime");
    cands.push_back("/usr/share/pryany/runtime");
    for (auto &c : cands)
        if (std::filesystem::exists(joinPath(c, "pryany.h"))) return c;
    return joinPath(std::filesystem::path(ed).parent_path().string(), "runtime");
}

std::string readFile(const std::string &path, bool &ok) {
    std::ifstream f(path, std::ios::binary);
    if (!f) {
        ok = false;
        return "";
    }
    std::stringstream ss;
    ss << f.rdbuf();
    ok = true;
    return ss.str();
}

std::string Runner::transpile(const std::string &src, const std::string &srcFile, int silentBefore,
                              std::string &err) {
    try {
        auto toks = lex(src);
        auto prog = parse(toks);
        return generate(prog, srcFile, silentBefore);
    } catch (const PryError &e) {
        std::ostringstream o;
        o << "�﷨����";
        if (e.line > 0) o << "���� " << e.line << " �У�";
        o << "��" << e.what();
        err = o.str();
        return "";
    } catch (const std::exception &e) {
        err = std::string("����ʧ�ܣ�") + e.what();
        return "";
    }
}

static std::string shquote(const std::string &s) {
#ifdef _WIN32
    return "\"" + s + "\"";
#else
    std::string r = "'";
    for (char c : s)
        if (c == '\'') r += "'\\''";
        else r += c;
    return r + "'";
#endif
}

bool Runner::compile(const std::string &cppCode, const std::string &cppPath,
                     const std::string &binPath, std::string &log, double &ms) {
    std::filesystem::create_directories(std::filesystem::path(cppPath).parent_path());
    {
        std::ofstream f(cppPath);
        f << cppCode;
    }
    auto t0 = std::chrono::steady_clock::now();
    std::string gpp = findGpp();
    std::string cmd = gpp + " -std=c++17 -O1 -w -I" + shquote(runtimeDir) + " " + shquote(cppPath) +
                      " -o " + shquote(binPath) + " 2>&1";
#ifdef _WIN32
    cmd = gpp + " -std=c++17 -O1 -w -I\"" + runtimeDir + "\" \"" + cppPath + "\" -o \"" + binPath +
          "\" 2>&1";
#endif
    FILE *pipe = popen(cmd.c_str(), "r");
    if (!pipe) {
        log = "�޷����� g++����ȷ���Ѱ�װ g++ ������ PATH ��";
        return false;
    }
    std::string out;
    char buf[4096];
    while (fgets(buf, sizeof(buf), pipe)) out += buf;
    int rc = pclose(pipe);
    auto t1 = std::chrono::steady_clock::now();
    ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    log = out;
    return rc == 0;
}

int Runner::run(const std::string &binPath, double &ms) {
    auto t0 = std::chrono::steady_clock::now();
#ifdef _WIN32
    std::string cmd = "\"" + binPath + "\"";
#else
    std::string cmd = shquote(binPath);
#endif
    FILE *pipe = popen(cmd.c_str(), "r");
    if (!pipe) return 1;
    char buf[4096];
    while (fgets(buf, sizeof(buf), pipe)) {
        std::fwrite(buf, 1, std::strlen(buf), stdout);
    }
    std::fflush(stdout);
    int rc = pclose(pipe);
    auto t1 = std::chrono::steady_clock::now();
    ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
#ifdef _WIN32
    return rc;
#else
    return WIFEXITED(rc) ? WEXITSTATUS(rc) : 1;
#endif
}
