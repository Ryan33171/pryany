// pryany �ʷ�������
#include "pry_common.h"
#include <cctype>
#include <set>

static const std::set<std::string> kKeywords = {
    "fn", "ret", "if", "elif", "else", "while", "for", "in", "break", "continue",
    "and", "or", "not", "true", "false", "nil", "say", "print", "use", "cpp",
    "del", "new", "int", "float", "str", "bool", "ptr", "raw", "any", "sizeof", "ask",
    "head", "pkuip", "pku", "pk"
};

static const std::vector<std::string> kOpsLongFirst = {
    "**", "//", "==", "!=", "<=", ">=", "<<", ">>",
    "->", "=", "+", "-", "*", "/", "%", "<", ">", "!", "&", "|", "^", "~",
    "(", ")", "[", "]", "{", "}", ",", ".", ":", ";", "@", "$"
};

static bool isIdentStart(char c) { return std::isalpha((unsigned char)c) || c == '_'; }
static bool isIdentChar(char c) { return std::isalnum((unsigned char)c) || c == '_'; }

// ��ȡ cpp { ... } ԭʼ�飬src[i] ָ�� '{'
static std::string readRawBlock(const std::string &src, size_t &i, int &line) {
    size_t start = i;  // '{'
    int depth = 0;
    while (i < src.size()) {
        char c = src[i];
        if (c == '\n') { line++; i++; continue; }
        if (c == '"' || c == '\'') {
            char q = c;
            i++;
            while (i < src.size() && src[i] != q) {
                if (src[i] == '\\') i++;
                if (src[i] == '\n') line++;
                i++;
            }
            i++;
            continue;
        }
        if (c == '/' && i + 1 < src.size() && src[i + 1] == '/') {
            while (i < src.size() && src[i] != '\n') i++;
            continue;
        }
        if (c == '/' && i + 1 < src.size() && src[i + 1] == '*') {
            i += 2;
            while (i + 1 < src.size() && !(src[i] == '*' && src[i + 1] == '/')) {
                if (src[i] == '\n') line++;
                i++;
            }
            i += 2;
            continue;
        }
        if (c == '#') {
            while (i < src.size() && src[i] != '\n') i++;
            continue;
        }
        if (c == '{') depth++;
        else if (c == '}') {
            depth--;
            if (depth == 0) { i++; break; }
        }
        i++;
    }
    return src.substr(start + 1, i - start - 2);  // ȥ����㻨����
}

std::vector<Token> lex(const std::string &src) {
    std::vector<Token> out;
    size_t i = 0;
    int line = 1;
    int depth = 0;  // ������ȣ������ж��ã�
    bool lineHasToken = false;
    std::string lastOp;

    auto push = [&](Tok t, const std::string &text, int ln) {
        Token tk;
        tk.type = t;
        tk.text = text;
        tk.line = ln;
        out.push_back(tk);
        lineHasToken = true;
    };

    while (i < src.size()) {
        char c = src[i];
        if (c == '\n') {
            // �ж��Ƿ�����
            if (lineHasToken && depth <= 0 && lastOp != "{" && lastOp != "[" &&
                lastOp != "(" && lastOp != "," && lastOp != "\\" && lastOp != ":" &&
                lastOp != "->" && lastOp != "=" && lastOp != "+" && lastOp != "-" &&
                lastOp != "*" && lastOp != "/" && lastOp != "%" && lastOp != "**" &&
                lastOp != "//" && lastOp != "==" && lastOp != "!=" && lastOp != "<" &&
                lastOp != ">" && lastOp != "<=" && lastOp != ">=" && lastOp != "&" &&
                lastOp != "|" && lastOp != "^" && lastOp != "~" && lastOp != "<<" &&
                lastOp != ">>" && lastOp != "." && lastOp != "and" && lastOp != "or" &&
                lastOp != "not" && lastOp != "in") {
                out.push_back({Tok::Newline, "\n", line});
            }
            line++;
            i++;
            lineHasToken = false;
            lastOp.clear();
            depth = 0;
            continue;
        }
        if (c == ' ' || c == '\t' || c == '\r') { i++; continue; }
        if (c == '\\' && i + 1 < src.size() && src[i + 1] == '\n') {
            i += 2;
            line++;
            lastOp = "\\";
            continue;
        }
        if (c == '#') {  // ע��
            while (i < src.size() && src[i] != '\n') i++;
            continue;
        }
        if (c == ';') {
            out.push_back({Tok::Newline, ";", line});
            i++;
            lastOp.clear();
            lineHasToken = false;
            continue;
        }
        if (c == '"') {  // �ַ���
            int ln = line;
            i++;
            std::string v;
            while (i < src.size() && src[i] != '"') {
                if (src[i] == '\\' && i + 1 < src.size()) {
                    char e = src[i + 1];
                    i += 2;
                    switch (e) {
                    case 'n': v += '\n'; break;
                    case 't': v += '\t'; break;
                    case 'r': v += '\r'; break;
                    case '0': v += '\0'; break;
                    case '\\': v += '\\'; break;
                    case '"': v += '"'; break;
                    default: v += e;
                    }
                    continue;
                }
                if (src[i] == '\n') pryFail("�ַ���û�бպϵ�����", ln);
                v += src[i];
                i++;
            }
            if (i >= src.size()) pryFail("�ַ���û�бպϵ�����", ln);
            i++;
            push(Tok::Str, v, ln);
            lastOp.clear();
            continue;
        }
        if (std::isdigit((unsigned char)c)) {  // ����
            int ln = line;
            size_t st = i;
            if (c == '0' && i + 1 < src.size() && (src[i + 1] == 'x' || src[i + 1] == 'X')) {
                i += 2;
                while (i < src.size() && std::isxdigit((unsigned char)src[i])) i++;
            } else {
                while (i < src.size() && std::isdigit((unsigned char)src[i])) i++;
                if (i < src.size() && src[i] == '.' && i + 1 < src.size() &&
                    std::isdigit((unsigned char)src[i + 1])) {
                    i++;
                    while (i < src.size() && std::isdigit((unsigned char)src[i])) i++;
                }
            }
            push(Tok::Num, src.substr(st, i - st), ln);
            lastOp.clear();
            continue;
        }
        if (isIdentStart(c)) {  // ��ʶ�� / �ؼ��� / cpp ��
            int ln = line;
            size_t st = i;
            while (i < src.size() && isIdentChar(src[i])) i++;
            std::string w = src.substr(st, i - st);
            if (w == "cpp" || w == "head") {
                size_t j = i;
                while (j < src.size() && (src[j] == ' ' || src[j] == '\t')) j++;
                if (j < src.size() && src[j] == '{') {
                    int l2 = ln;
                    i = j;
                    std::string raw = readRawBlock(src, i, l2);
                    line = l2;
                    Token tk;
                    tk.type = (w == "head") ? Tok::RawHead : Tok::Raw;
                    tk.text = raw;
                    tk.line = ln;
                    out.push_back(tk);
                    lineHasToken = true;
                    lastOp.clear();
                    continue;
                }
            }
            push(kKeywords.count(w) ? Tok::Key : Tok::Ident, w, ln);
            lastOp = w;
            continue;
        }
        // �����
        bool matched = false;
        for (auto &op : kOpsLongFirst) {
            if (src.compare(i, op.size(), op) == 0) {
                int ln = line;
                push(Tok::Op, op, ln);
                i += op.size();
                lastOp = op;
                if (op == "(" || op == "[" || op == "{") depth++;
                else if (op == ")" || op == "]" || op == "}") depth--;
                matched = true;
                break;
            }
        }
        if (!matched) pryFail(std::string("�޷�ʶ����ַ�: '") + c + "'", line);
    }
    if (lineHasToken) out.push_back({Tok::Newline, "\n", line});
    out.push_back({Tok::End, "", line});
    return out;
}
