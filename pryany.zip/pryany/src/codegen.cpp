// pryany �������������� pryany �﷨������� C++17 Դ��
#include "pry_common.h"
#include "runner.h"
#include <filesystem>
#include <cstdio>
#include <fstream>
#include <map>
#include <set>
#include <sstream>
#include <fstream>
#ifdef _WIN32
#include <process.h>
#else
#include <unistd.h>
#endif
static const std::map<std::string, std::string> kBuiltins = {
    {"len", "len"},       {"push", "push"},     {"pop", "pop"},
    {"str", "tostr"},     {"int", "toint"},     {"float", "toflt"},
    {"bool", "tobool"},   {"type", "type"},     {"abs", "abs_"},
    {"min", "min_"},      {"max", "max_"},      {"sqrt", "sqrt_"},
    {"pow", "pow_"},      {"floor", "floor_"},  {"ceil", "ceil_"},
    {"sin", "sin_"},      {"cos", "cos_"},      {"time", "time_"},
    {"sleep", "sleep_"},  {"rand", "rand_"},    {"exit", "exit_"},
    {"range", "range_"},  {"input", "input_"},  {"ask", "input_"},
    {"upper", "upper"},   {"lower", "lower"},   {"trim", "trim"},
    {"split", "split"},   {"join", "join"},     {"contains", "contains"},
    {"reverse", "reverse_"}, {"sort", "sort_"}, {"slice", "slice"},
    {"alloc", "alloc"},   {"free", "freep"},    {"peek", "peek"},
    {"poke", "poke"},     {"peek4", "peek4"},   {"poke4", "poke4"},
    {"peek8", "peek8"},   {"poke8", "poke8"},   {"memset", "memfill"},
    {"memcpy", "memcopy"},{"memcmp", "memcmp_"},{"addr", "addr"},
    {"toptr", "toptr"},   {"dump", "dumphex"},  {"print", "print"},
};

static bool isPtrType(const std::string &t) { return !t.empty() && t.back() == '*'; }

static bool isIntLike(const std::string &t) {
    static const std::set<std::string> k = {"long long", "int", "short", "char", "unsigned char",
                                           "unsigned", "unsigned int", "unsigned short",
                                           "unsigned long", "long", "size_t", "std::size_t"};
    return k.count(t) > 0;
}

static std::string defaultFor(const std::string &ctype) {
    if (ctype == "pry::Val") return "pry::Val()";
    if (ctype == "long long") return "0";
    if (ctype == "double") return "0";
    if (ctype == "std::string") return "\"\"";
    if (ctype == "bool") return "false";
    if (isPtrType(ctype)) return "nullptr";
    return "0";  // �����������ͣ��� unsigned char��Ĭ�� 0
}

static std::string escapeC(const std::string &s) {
    std::string r = "\"";
    for (unsigned char c : s) {
        switch (c) {
        case '"': r += "\\\""; break;
        case '\\': r += "\\\\"; break;
        case '\n': r += "\\n"; break;
        case '\t': r += "\\t"; break;
        case '\r': r += "\\r"; break;
        case '\0': r += "\\0"; break;
        default:
            if (c < 32 || c == 127) {
                char buf[8];
                std::snprintf(buf, sizeof(buf), "\\x%02x", c);
                r += buf;
            } else {
                r += (char)c;
            }
        }
    }
    return r + "\"";
}

// ---------------- pkuip ������ ----------------
// pkuip ����һ����ִ���ļ� script/����.exe��֧�����ֵ��÷�ʽ��
//   exe --info                 ��ӡ�ð����С��ɵ��ú��������б���ÿ��һ������ count()��
//   exe --call "count(1)"      ��ԭʼ�����ַ������룬��ӡ��Ҫ���е� C++ ���롿
// ���ͳһ������ı�ǰ�����������ֻȡ���֮������ݣ�
//   ===PKUIP-BEGIN===
//   ...����...
//   ===PKUIP-END===
struct PkuPackage {
    std::string funcs;   // --info ������ɵ��ú������б���ԭʼ�ı���
    std::set<std::string> exports;  // �������ĺ�������ȥ���ţ�����
    std::string exe;     // �ð���ִ���ļ���ʵ��·��
    bool ok = false;
};

static std::string pkuSuffix() {
#ifdef _WIN32
    return ".exe";
#else
    return "";
#endif
}

// �ڶ����ѡĿ¼�ж�λ script/����(.exe)
static std::string findPkuExe(const std::string &pkg, const std::string &baseDir) {
    std::vector<std::string> names = {pkg, pkg + ".exe"};
    std::vector<std::string> dirs = {
        (std::filesystem::path(baseDir) / "script").string(),
        (std::filesystem::path(baseDir) / ".." / "script").string(),
        (std::filesystem::path("script")).string(),
    };
    try { dirs.insert(dirs.begin(), (std::filesystem::path(exeDir()) / "script").string()); } catch (...) {}
    for (auto &dn : dirs)
        for (auto &nm : names) {
            std::string c = (std::filesystem::path(dn) / nm).string();
            if (std::filesystem::exists(c)) return std::filesystem::weakly_canonical(c).string();
        }
    return "";
}

// ִ��һ��������� stdout���ϲ� stderr��
static std::string pkuRun(const std::string &cmd) {
    FILE *pipe = popen(cmd.c_str(), "r");
    if (!pipe) return "";
    std::string out;
    char buf[4096];
    while (fgets(buf, sizeof(buf), pipe)) out += buf;
    int rc = pclose(pipe);
    (void)rc;
    return out;
}

static std::string pkuExtract(const std::string &out, const std::string &pkg) {
    if (out.empty())
        pryFail("�� " + pkg + " ��������Ϊ��", 0);
    return out;
}

static void pkuTrim(std::string &s) {
    size_t i = 0, j = s.size();
    while (i < j && (s[i] == '\n' || s[i] == '\r' || s[i] == ' ' || s[i] == '\t')) i++;
    while (j > i && (s[j - 1] == '\n' || s[j - 1] == '\r' || s[j - 1] == ' ' || s[j - 1] == '\t')) j--;
    s = s.substr(i, j - i);
}

// ����һ������������Ϣ������ exe --info��
static PkuPackage loadPkuPackage(const std::string &pkg, const std::string &baseDir) {
    PkuPackage r;
    r.exe = findPkuExe(pkg, baseDir);
    if (r.exe.empty())
        pryFail("�Ҳ������ļ�: " + pkg + "���Ѳ��� script/" + pkg + "[.exe] ��λ�ã�", 0);
    std::string info = pkuExtract(pkuRun("\"" + r.exe + "\" --info 2>&1"), pkg);
    r.funcs = info;
    // ������������ÿ������ count() �� count(a, b)��ȡ '(' ֮ǰ������
    std::string cur;
    std::vector<std::string> names;
    std::stringstream ss(info);
    std::string ln;
    while (std::getline(ss, ln)) {
        pkuTrim(ln);
        if (ln.empty() || ln[0] == '#') continue;
        size_t p = ln.find('(');
        std::string nm = (p == std::string::npos) ? ln : ln.substr(0, p);
        pkuTrim(nm);
        if (!nm.empty()) r.exports.insert(nm);
    }
    r.ok = true;
    return r;
}

// �ð�����һ�� C++ ���룺��ԭʼ�����ַ���д����ʱ�ļ���������
// ����ȡ���ļ�������Ҫ���е� C++ ���롣
// ������ʱ�ļ����������в�������������ı��������/�ո� shell �ƻ���
static std::string pkuGenCode(const std::string &exe, const std::string &pkg,
                              const std::string &callText) {
    namespace fs = std::filesystem;
    fs::path dir = fs::temp_directory_path() / ("pryany_pku_" + std::to_string(
#ifdef _WIN32
        (long long)_getpid()
#else
        (long long)::getpid()
#endif
    ));
    std::error_code ec;
    fs::create_directories(dir, ec);
    fs::path callFile = dir / "call.txt";
    {
        std::ofstream f(callFile, std::ios::binary);
        f << callText;
    }
    std::string out = pkuRun("\"" + exe + "\" --call-file \"" + callFile.string() + "\" 2>&1");
    std::string body = pkuExtract(out, pkg);
    pkuTrim(body);
    return body;
}

struct CodeGen {
    std::string srcFile = "<pryany>";
    std::string baseDir = ".";
    std::vector<std::map<std::string, std::string>> scopes;
    std::set<std::string> functions;
    std::map<std::string, std::vector<std::string>> funcSigs;  // ������ -> ���� C++ ����
    std::map<std::string, std::string> funcRet;                 // ������ -> ���� C++ ����
    std::set<std::string> included, emitted, funcsEmitted;
    bool silent = false;
    std::map<std::string, std::vector<StmtP>> modCache;
    std::map<std::string, std::string> globalVars;  // ������� -> ctype
    std::map<std::string, std::pair<std::string, bool>> newAllocs;  // ���� -> (����, �Ƿ�����)
    std::set<std::string> stackPtrs;               // ���� -> �� &x �õ���ջ��ַ������ delete��
    std::map<std::string, PkuPackage> pkuCache;     // �Ѽ��صİ�����������
    std::set<std::string> pkuLoaded;               // �ѵ���İ���
    std::ostringstream headCpp;    // pkuip �����ɵ� C++ ����Ƭ�Σ��ŵ��ļ�ͷ����
    std::ostringstream declOut;   // ȫ�ֱ��� + ����
    std::ostringstream bodyOut;   // pry_main ������
    int depth = 0;                // �����㼶
    bool inFunc = false;           // ��ǰ�Ƿ��ں�������
    std::string curRetType;        // ��ǰ�����ķ������ͣ��� = pry::Val��
    int uid = 0;

    CodeGen() { scopes.push_back({}); }

    // ---------- ������ ----------
    void push() { scopes.push_back({}); }
    void pop() { scopes.pop_back(); }
    bool declared(const std::string &n) {
        for (auto it = scopes.rbegin(); it != scopes.rend(); ++it)
            if (it->count(n)) return true;
        return false;
    }
    bool declaredHere(const std::string &n) { return scopes.back().count(n) > 0; }
    std::string varType(const std::string &n) {
        for (auto it = scopes.rbegin(); it != scopes.rend(); ++it) {
            auto f = it->find(n);
            if (f != it->end()) return f->second;
        }
        return "";
    }
    void declare(const std::string &n, const std::string &t) { scopes.back()[n] = t; }

    // ---------- pkuip �� ----------
    // ����һ���������� exe --info ȡ�ÿɵ��ú������б����Ǽ�Ϊ��������
    // ע�⣺����������Դ�벢�뱾���������Ĵ����ڵ��õ��� exe ��̬���ɡ�
    void loadPku(const std::string &pkg) {
        if (pkuLoaded.count(pkg)) return;
        pkuLoaded.insert(pkg);
        pkuCache[pkg] = loadPkuPackage(pkg, baseDir);
    }

    // �ڵ��õ�����������ɵ� C++ ���루��ԭʼ�����ַ�����
    std::string pkuCode(const std::string &pkg, const std::string &callText) {
        auto it = pkuCache.find(pkg);
        if (it == pkuCache.end() || !it->second.ok)
            pryFail("�� '" + pkg + "' δ���룬�����ڶ���д  pkuip " + pkg, 0);
        return pkuGenCode(it->second.exe, pkg, callText);
    }

    // ��һ������ʽ��ԭ�� pryany Դ�Ľ����ı������ڴ����� exe���� count(1)��
    std::string pkuArgText(const ExprP &e) {
        switch (e->k) {
        case Expr::Num: return e->a;
        case Expr::Str: return "\"" + e->a + "\"";
        case Expr::Bool: return e->bval ? "true" : "false";
        case Expr::Nil: return "nil";
        case Expr::Var: return e->a;
        case Expr::Bin: return pkuArgText(e->kids[0]) + " " + e->a + " " + pkuArgText(e->kids[1]);
        case Expr::Un: return e->a + pkuArgText(e->kids[0]);
        case Expr::Call: {
            std::string r = pkuArgText(e->kids[0]) + "(";
            for (size_t j = 1; j < e->kids.size(); j++) {
                if (j > 1) r += ", ";
                r += pkuArgText(e->kids[j]);
            }
            return r + ")";
        }
        case Expr::Member: {
            std::string r = pkuArgText(e->kids[0]) + "." + e->a;
            if (e->kids.size() > 1) {
                r += "(";
                for (size_t j = 1; j < e->kids.size(); j++) {
                    if (j > 1) r += ", ";
                    r += pkuArgText(e->kids[j]);
                }
                r += ")";
            }
            return r;
        }
        case Expr::Index: return pkuArgText(e->kids[0]) + "[" + pkuArgText(e->kids[1]) + "]";
        case Expr::ListE: {
            std::string r = "[";
            for (size_t j = 0; j < e->kids.size(); j++) {
                if (j) r += ", ";
                r += pkuArgText(e->kids[j]);
            }
            return r + "]";
        }
        default: return e->a;
        }
    }

    // ---------- ��¼ new / & �����ı������� del ѡ�� delete / delete[] / ʲô������ ----------
    void noteAlloc(const std::string &name, const ExprP &rhs) {
        if (name.empty() || !rhs) return;
        if (rhs->k == Expr::NewE) newAllocs[name] = {rhs->a, !rhs->kids.empty()};
        else if (rhs->k == Expr::Un && rhs->a == "&") stackPtrs.insert(name);
    }

    void line(int ln) { bodyOut << "#line " << ln << " \"" << srcFile << "\"\n"; }
    void ind() { bodyOut << std::string((size_t)depth * 2 + 2, ' '); }

    // ---------- ģ�� ----------
    std::vector<StmtP> &module(const std::string &rel) {
        std::filesystem::path p = std::filesystem::path(baseDir) / rel;
        std::string key = std::filesystem::weakly_canonical(p).string();
        auto it = modCache.find(key);
        if (it != modCache.end()) return it->second;
        std::ifstream f(key);
        if (!f) pryFail("�޷���ģ���ļ�: " + rel + " ������·�� " + key + "��", 0);
        std::stringstream ss;
        ss << f.rdbuf();
        auto &v = modCache[key];
        v = parse(lex(ss.str()));
        return v;
    }

    // ---------- ����ʽ ----------
    std::string genVal(const ExprP &e);
    std::string genRawTarget(const ExprP &e, const std::string &ctype);
    std::string convert(const std::string &v, const std::string &ctype) {
        if (ctype.empty() || ctype == "pry::Val") return v;
        if (ctype == "long long") return "((" + v + ").asInt())";
        if (ctype == "double") return "((" + v + ").asFlt())";
        if (ctype == "std::string") return "((" + v + ").asStr())";
        if (ctype == "bool") return "((" + v + ").asBool())";
        if (isPtrType(ctype)) return "((" + ctype + ")((" + v + ").ptr()))";
        if (isIntLike(ctype)) return "((" + v + ").asInt())";
        if (ctype == "float") return "((" + v + ").asFlt())";
        return v;
    }

    // ��һ������ʽ�� C++ ԭʼ���ͣ����� & �� *��
    std::string exprType(const ExprP &e) {
        if (e->k == Expr::Var) return varType(e->a);
        if (e->k == Expr::Un && e->a == "*") {
            std::string t = exprType(e->kids[0]);
            if (isPtrType(t)) return t.substr(0, t.size() - 1);
            return "pry::Val";
        }
        return "pry::Val";
    }

    std::string genLValueRaw(const ExprP &e) {  // ���ɿ�ֱ��ȡ��ַ�� C++ ��ֵ
        if (e->k == Expr::Var) return e->a;
        if (e->k == Expr::Un && e->a == "*") return "(*(" + genLValueRaw(e->kids[0]) + "))";
        pryFail("������Ҫһ������ȡ��ַ����ֵ", e->line);
    }

    std::string genDeref(const ExprP &e) {  // *p
        ExprP target = e->kids[0];
        std::string t = exprType(target);
        // ��ָ̬�루pry::Val ��װ�ĵ�ַ������ 8 �ֽڶ�д���� new int һ��
        if (t == "pry::Val" || t.empty())
            return "pry::Val((long long)*(long long*)((" + genVal(target) + ").ptr()))";
        std::string raw = "*(" + (target->k == Expr::Var ? target->a : genRawOf(target)) + ")";
        if (t == "unsigned char*") return "pry::Val((long long)" + raw + ")";
        if (t == "long long*") return "pry::Val(" + raw + ")";
        if (t == "double*") return "pry::Val(" + raw + ")";
        if (t == "std::string*") return "pry::Val(" + raw + ")";
        if (t == "bool*") return "pry::Val(" + raw + ")";
        pryFail("���ܽ����ø����ͣ�������Ϊ int* / float* / raw* �ȴ����͵�ָ�룩", e->line);
    }

    std::string genRawOf(const ExprP &e);  // ����ԭ�� C++ ����ʽ������װΪ Val��

    std::string pointeeAssign(const ExprP &e, const std::string &valExpr) {
        // *p = v
        ExprP target = e->kids[0];
        std::string t = exprType(target);
        if (t == "pry::Val" || t.empty())  // ��ָ̬�룺�� 8 �ֽ�д
            return "*((long long*)((" + genVal(target) + ").ptr())) = ((" + valExpr + ").asInt())";
        std::string lhs = "*(" + (target->k == Expr::Var ? target->a : genRawOf(target)) + ")";
        if (t == "unsigned char*") return lhs + " = (unsigned char)((" + valExpr + ").asInt())";
        if (t == "long long*") return lhs + " = ((" + valExpr + ").asInt())";
        if (t == "double*") return lhs + " = ((" + valExpr + ").asFlt())";
        if (t == "bool*") return lhs + " = ((" + valExpr + ").asBool())";
        if (t == "std::string*") return lhs + " = ((" + valExpr + ").asStr())";
        pryFail("���ܸ���ָ�����͸�ֵ������ int* / float* / raw* �ȣ�", e->line);
    }

    // ---------- ��� ----------
    void emitBlock(const std::vector<StmtP> &body) {
        push();
        for (auto &s : body) emitStmt(s);
        pop();
    }

    void emitStmt(const StmtP &s);
    void emitStmts(const std::vector<StmtP> &prog, int lnHint) {
        (void)lnHint;
        for (auto &s : prog) emitStmt(s);
    }

    // ---------- �ռ� ----------
    void collect(const std::vector<StmtP> &prog) {
        for (auto &s : prog) {
            if (s->k == Stmt::Fn) {
                functions.insert(s->name);
                std::vector<std::string> sig;
                for (size_t j = 0; j < s->params.size(); j++)
                    sig.push_back(s->paramTypes[j].empty() ? "pry::Val" : s->paramTypes[j]);
                funcSigs[s->name] = sig;
                funcRet[s->name] = s->retType;
            } else if (s->k == Stmt::Assign && !s->declType.empty()) {
                globalVars[s->name] = s->declType;
                scopes[0][s->name] = s->declType;
            } else if (s->k == Stmt::Assign) {
                // x = ... ������ʽ����Ϊ��̬����
                if (s->e && s->e->k == Expr::Var && !declared(s->e->a)) {
                    globalVars[s->e->a] = "pry::Val";
                    scopes[0][s->e->a] = "pry::Val";
                }
            } else if (s->k == Stmt::Ask && !s->name.empty()) {
                if (!declared(s->name)) {
                    globalVars[s->name] = "pry::Val";
                    scopes[0][s->name] = "pry::Val";
                }
            } else if (s->k == Stmt::Use) {
                std::string key = std::filesystem::weakly_canonical(
                                      std::filesystem::path(baseDir) / s->name)
                                      .string();
                if (included.insert(key).second) {
                    std::string oldDir = baseDir;
                    baseDir = std::filesystem::path(key).parent_path().string();
                    collect(module(std::filesystem::path(key).filename().string()));
                    baseDir = oldDir;
                }
            } else if (s->k == Stmt::Pkuip) {
                loadPku(s->name);
            }
        }
    }

    // ---------- ����������� ----------
    void emitFunc(const StmtP &s) {
        std::string ret = s->retType.empty() ? "pry::Val" : s->retType;
        declOut << ret << " " << s->name << "(";
        for (size_t j = 0; j < s->params.size(); j++) {
            if (j) declOut << ", ";
            declOut << (s->paramTypes[j].empty() ? "pry::Val" : s->paramTypes[j]) << " "
                    << s->params[j];
        }
        declOut << ") {\n";
        // ��������������л���������
        std::ostringstream save;
        save << bodyOut.str();
        bodyOut.str("");
        bodyOut.clear();
        depth = 0;
        inFunc = true;
        curRetType = s->retType;
        push();
        for (size_t j = 0; j < s->params.size(); j++)
            declare(s->params[j], s->paramTypes[j].empty() ? "pry::Val" : s->paramTypes[j]);
        std::string oldFile = srcFile;
        for (auto &b : s->body) emitStmt(b);
        srcFile = oldFile;
        pop();
        bodyOut << "  return " << defaultFor(ret) << ";\n}\n";
        declOut << bodyOut.str();
        bodyOut.str("");
        bodyOut.clear();
        bodyOut << save.str();
        depth = 0;
        inFunc = false;
        curRetType.clear();
    }

    void emitFuncs(const std::vector<StmtP> &prog) {
        for (auto &s : prog) {
            if (s->k == Stmt::Fn) emitFunc(s);
            else if (s->k == Stmt::Use) {
                std::string key = std::filesystem::weakly_canonical(
                                      std::filesystem::path(baseDir) / s->name)
                                      .string();
                if (funcsEmitted.insert(key).second) {
                    std::string oldDir = baseDir, oldFile = srcFile;
                    baseDir = std::filesystem::path(key).parent_path().string();
                    srcFile = key;  // ��ģ�麯���� #line ָ��ģ���ļ�
                    emitFuncs(module(std::filesystem::path(key).filename().string()));
                    baseDir = oldDir;
                    srcFile = oldFile;
                }
            }
            // ע�⣺pkuip ���ĺ����塾�������������ɡ���
            // ����ʵ���� [cpp] ���ṩ��headCpp������������ظ����塣
        }
    }
};

// ---------- ����ʽ���� ----------
std::string CodeGen::genRawOf(const ExprP &e) {
    if (e->k == Expr::Var) return e->a;
    if (e->k == Expr::Un && e->a == "*")
        return "*(" + (e->kids[0]->k == Expr::Var ? e->kids[0]->a : genRawOf(e->kids[0])) + ")";
    if (e->k == Expr::RawCpp) return e->a;
    if (e->k == Expr::Index) {
        std::string t = exprType(e->kids[0]);
        if (isPtrType(t)) return "(" + genRawOf(e->kids[0]) + ")[(" + genVal(e->kids[1]) + ").asInt()]";
        return "(" + genVal(e) + ")";
    }
    return "(" + genVal(e) + ")";
}

std::string CodeGen::genVal(const ExprP &e) {
    switch (e->k) {
    case Expr::Num: {
        std::string t = e->a;
        bool isFloat = t.find('.') != std::string::npos;
        return "pry::Val(" + t + (isFloat ? "" : "LL") + ")";
    }
    case Expr::Str: return "pry::Val(std::string(" + escapeC(e->a) + "))";
    case Expr::Bool: return std::string("pry::Val(") + (e->bval ? "true" : "false") + ")";
    case Expr::Nil: return "pry::Val()";
    case Expr::RawCpp: return "(" + e->a + ")";
    case Expr::Var: {
        std::string t = varType(e->a);
        if (t.empty()) {
            if (functions.count(e->a))
                pryFail("'" + e->a + "' ��һ������������ʱҪ������ " + e->a + "()", e->line);
            pryFail("δ����ı��� '" + e->a + "'��pryany ��Ҫ�ȸ�ֵ��ʹ�ã�", e->line);
        }
        if (t == "pry::Val") return e->a;
        if (isPtrType(t)) return "pry::Val((void*)(" + e->a + "))";
        return "pry::Val(" + e->a + ")";
    }
    case Expr::Un: {
        if (e->a == "-") return "(-(" + genVal(e->kids[0]) + "))";
        if (e->a == "not") return "pry::Val(!pry::truthy(" + genVal(e->kids[0]) + "))";
        if (e->a == "~") return "pry::Val(~(" + genVal(e->kids[0]) + ").asInt())";
        if (e->a == "&") {
            std::string t = exprType(e->kids[0]);
            if (t == "pry::Val" || t.empty())
                pryFail("���ܶԶ�̬����ȡ��ַ����������ʽ������������ int x = 1 / raw buf[8]��",
                        e->line);
            return "pry::Val((void*)&(" + genLValueRaw(e->kids[0]) + "))";
        }
        if (e->a == "*") return genDeref(e);
        pryFail("δ֪��һԪ����", e->line);
    }
    case Expr::Bin: {
        std::string a = genVal(e->kids[0]), b = genVal(e->kids[1]);
        std::string op = e->a;
        // �� Python һ�£�and / or ���ز��������������ұ��ֶ�·
        if (op == "and") return "(pry::truthy(" + a + ") ? (" + b + ") : (" + a + "))";
        if (op == "or") return "(pry::truthy(" + a + ") ? (" + a + ") : (" + b + "))";
        if (op == "==") return "pry::Val((" + a + ") == (" + b + "))";
        if (op == "!=") return "pry::Val((" + a + ") != (" + b + "))";
        if (op == "<" || op == ">" || op == "<=" || op == ">=")
            return "pry::Val((" + a + ") " + op + " (" + b + "))";
        if (op == "//") return "pry::idiv(" + a + ", " + b + ")";
        if (op == "**") return "pry::power(" + a + ", " + b + ")";
        if (op == "&" || op == "|" || op == "^" || op == "<<" || op == ">>")
            return "pry::Val((" + a + ").asInt() " + op + " (" + b + ").asInt())";
        return "((" + a + ") " + op + " (" + b + "))";
    }
    case Expr::Index: {
        std::string obj = genVal(e->kids[0]), idx = genVal(e->kids[1]);
        std::string t = exprType(e->kids[0]);
        if (t == "pry::Val") return "(" + obj + ").get(" + idx + ")";
        if (isPtrType(t)) {
            std::string raw = genRawOf(e->kids[0]);
            if (t == "unsigned char*")
                return "pry::Val((long long)(" + raw + ")[(" + idx + ").asInt()])";
            if (t == "void*") pryFail("void* �����±���ʣ����� raw* �� int* �ȴ����͵�ָ��", e->line);
            return "pry::Val(((" + raw + ")[(" + idx + ").asInt()]))";
        }
        if (t == "std::string")
            return "pry::Val(std::string(1, (" + obj + ")[(size_t)(" + idx + ").asInt()]))";
        return "(" + obj + ").get(" + idx + ")";
    }
    case Expr::Member: {
        std::string obj = genVal(e->kids[0]);
        std::string args;
        for (size_t j = 1; j < e->kids.size(); j++) {
            if (j > 1) args += ", ";
            args += genVal(e->kids[j]);
        }
        auto it = kBuiltins.find(e->a);
        if (it != kBuiltins.end()) {
            std::string call = "pry::" + it->second + "(" + obj;
            if (!args.empty()) call += ", " + args;
            return call + ")";
        }
        // �����ã���ԭ�� C++ ��Ա��������� cpp{ } ʹ�ã�
        if (args.empty()) return "(" + obj + ")." + e->a;
        return "(" + obj + ")." + e->a + "(" + args + ")";
    }
    case Expr::Call: {
        ExprP callee = e->kids[0];
        std::vector<std::string> argVs;
        for (size_t j = 1; j < e->kids.size(); j++) argVs.push_back(genVal(e->kids[j]));
        std::string name;
        bool builtin = false;
        if (callee->k == Expr::Var) {
            name = callee->a;
            builtin = kBuiltins.count(name) > 0;
        } else if (callee->k == Expr::Member) {
            // a.b(...) ���� Member ���������ﶵ��
            return genVal(callee);
        }
        if (builtin) {
            std::string args;
            for (size_t j = 0; j < argVs.size(); j++) {
                if (j) args += ", ";
                args += argVs[j];
            }
            return "pry::" + kBuiltins.at(name) + "(" + args + ")";
        }
        // �û��������������Ĳ�������ת��ʵ�Σ�֧�� fn f(int a) ��������/��ֵ̬��
        auto sig = funcSigs.find(name);
        std::string args;
        for (size_t j = 0; j < argVs.size(); j++) {
            if (j) args += ", ";
            if (sig != funcSigs.end() && j < sig->second.size())
                args += convert(argVs[j], sig->second[j]);
            else
                args += argVs[j];
        }
        // ��һ�� Val����ʽ���͵ĺ�����: int / : bool / : str �������Ҳ�ܵ���ֵ̬��
        return "pry::Val(" + name + "(" + args + "))";
    }
    case Expr::ListE: {
        std::string r = "pry::Val(pry::List{";
        for (size_t j = 0; j < e->kids.size(); j++) {
            if (j) r += ", ";
            r += genVal(e->kids[j]);
        }
        return r + "})";
    }
    case Expr::NewE: {
        if (!e->kids.empty())
            return "pry::Val((void*)new " + e->a + "[(" + genVal(e->kids[0]) + ").asInt()])";
        return "pry::Val((void*)new " + e->a + ")";
    }
    case Expr::SizeofE: return "pry::Val((long long)sizeof(" + e->a + "))";
    case Expr::PkuCall: {
        // pku.����.����(����) -> ��ԭʼ�����ַ��������� exe��ȡ��Ҫ���е� C++ ����
        size_t dot = e->a.find('.');
        std::string pkg = e->a.substr(0, dot);
        std::string fn = e->a.substr(dot + 1);
        if (!pkuLoaded.count(pkg))
            pryFail("�� '" + pkg + "' δ���룬�����ڶ���д  pkuip " + pkg, e->line);
        auto pc = pkuCache.find(pkg);
        if (pc != pkuCache.end() && pc->second.ok && pc->second.exports.count(fn) == 0)
            pryFail("�� '" + pkg + "' û�пɵ��õĺ��� '" + fn + "'", e->line);
        // ��ԭԭʼ�����ַ��������� count(1) �� add(x, 2)
        std::string callText = fn + "(";
        for (size_t j = 0; j < e->kids.size(); j++) {
            if (j) callText += ", ";
            callText += pkuArgText(e->kids[j]);
        }
        callText += ")";
        // ���������룬��װ��һ��Ψһ���޲θ����������ŵ��ļ�ͷ��
        std::string code = pkuCode(pkg, callText);
        std::string helper = "__pku_" + pkg + "_" + fn + "_" + std::to_string(uid++);
        headCpp << "// pkuip �� " << pkg << " Ϊ���� " << callText << " ���ɵĴ���\n";
        headCpp << "static pry::Val " << helper << "() {\n" << code << "\n}\n";
        return helper + "()";
    }
    }
    pryFail("�޷����ɸñ���ʽ", e->line);
}

// ���ɸ�ֵ�Ҳࣨ��Ŀ�����ͣ�
std::string CodeGen::genRawTarget(const ExprP &e, const std::string &ctype) {
    if (ctype == "pry::Val" || ctype.empty()) return genVal(e);
    if (isPtrType(ctype)) {
        if (e->k == Expr::NewE) {
            if (!e->kids.empty())
                return "new " + e->a + "[(" + genVal(e->kids[0]) + ").asInt()]";
            return "new " + e->a;
        }
    }
    return convert(genVal(e), ctype);
}

// ---------- ������� ----------
void CodeGen::emitStmt(const StmtP &s) {
    line(s->line);
    switch (s->k) {
    case Stmt::Fn:
        if (depth > 0 || inFunc) pryFail("���������ں����ﶨ��", s->line);
        break;  // ���� emitFuncs ���
    case Stmt::Say: {
        ind();
        bodyOut << (silent ? "pry::silent(" : "pry::print(");
        for (size_t j = 0; j < s->exprs.size(); j++) {
            if (j) bodyOut << ", ";
            bodyOut << genVal(s->exprs[j]);
        }
        bodyOut << ");\n";
        break;
    }
    case Stmt::Ask: {
        ind();
        std::string prompt = s->e ? genVal(s->e) : "pry::Val(std::string(\"\"))";
        if (!s->name.empty()) {
            std::string t = varType(s->name);
            if (t.empty()) {
                if (depth == 0 && !inFunc)
                    pryFail("���� '" + s->name + "' δ����", s->line);
                bodyOut << "pry::Val " << s->name << " = pry::input_(" << prompt << ");\n";
                declare(s->name, "pry::Val");
            } else {
                bodyOut << s->name << " = " << convert("pry::input_(" + prompt + ")", t) << ";\n";
            }
        } else {
            bodyOut << "pry::input_(" << prompt << ");\n";
        }
        break;
    }
    case Stmt::Use: {
        std::string key =
            std::filesystem::weakly_canonical(std::filesystem::path(baseDir) / s->name).string();
        if (emitted.insert(key).second) {
            std::string oldFile = srcFile, oldDir = baseDir;
            srcFile = key;
            baseDir = std::filesystem::path(key).parent_path().string();
            bool oldSilent = silent;
            silent = true;
            // baseDir ���е�ģ������Ŀ¼������ֻ���ļ���������·����ƴ������
            for (auto &st : module(std::filesystem::path(key).filename().string()))
                if (st->k != Stmt::Fn) emitStmt(st);
            silent = oldSilent;
            srcFile = oldFile;
            baseDir = oldDir;
        }
        break;
    }
    case Stmt::RawCpp: {
        if (s->declType == "head") break;  // head{ } ��������ļ�ͷ��
        bodyOut << s->name << "\n";
        break;
    }
    case Stmt::Pkuip:
        // ����������Ϣ���� collect() �׶μ��أ���������ڵ��õ㶯̬���ɡ�
        break;
    case Stmt::Assign: {
        // ����ʽ��TYPE name = expr
        if (!s->declType.empty()) {
            std::string ctype = s->declType;
            noteAlloc(s->name, s->e);
            std::string rhs = s->e ? genRawTarget(s->e, ctype) : defaultFor(ctype);
            if (depth == 0) {  // �Ѿ���ȫ�ֱ���
                ind();
                bodyOut << s->name << " = " << rhs << ";\n";
            } else {
                if (declaredHere(s->name)) {
                    ind();
                    bodyOut << s->name << " = " << rhs << ";\n";
                } else {
                    ind();
                    bodyOut << ctype << " " << s->name << " = " << rhs << ";\n";
                    declare(s->name, ctype);
                }
            }
            break;
        }
        // x = expr / a[i] = expr / *p = expr
        ExprP lhs = s->e;
        noteAlloc(lhs->k == Expr::Var ? lhs->a : "", s->exprs[0]);
        std::string rhs = genVal(s->exprs[0]);
        if (lhs->k == Expr::Var) {
            std::string t = varType(lhs->a);
            if (t.empty()) {
                if (depth == 0 && !inFunc)
                    pryFail("δ����ı��� '" + lhs->a + "'��pryany ��Ҫ�ȸ�ֵ��ʹ�ã�", s->line);
                ind();
                bodyOut << "pry::Val " << lhs->a << " = " << rhs << ";\n";
                declare(lhs->a, "pry::Val");
            } else {
                ind();
                bodyOut << lhs->a << " = " << convert(rhs, t) << ";\n";
            }
        } else if (lhs->k == Expr::Index) {
            std::string t = exprType(lhs->kids[0]);
            if (t == "pry::Val") {
                ind();
                bodyOut << "(" << genVal(lhs->kids[0]) << ").set(" << genVal(lhs->kids[1]) << ", "
                        << rhs << ");\n";
            } else if (isPtrType(t)) {
                std::string el = t.substr(0, t.size() - 1);
                ind();
                bodyOut << genRawOf(lhs->kids[0]) << "[(" << genVal(lhs->kids[1]) << ").asInt()] = "
                        << convert(rhs, el) << ";\n";
            } else {
                pryFail("�����Ͳ�֧���±긳ֵ", s->line);
            }
        } else if (lhs->k == Expr::Un && lhs->a == "*") {
            ind();
            bodyOut << pointeeAssign(lhs, rhs) << ";\n";
        } else {
            pryFail("�Ⱥ���߲�����Ч�ĸ�ֵĿ��", s->line);
        }
        break;
    }
    case Stmt::ExprS: {
        ind();
        // �� (void) ��ֹ "pry::Val(f());" �� C++ ���ɺ���������most vexing parse��
        bodyOut << "(void)(" << genVal(s->e) << ");\n";
        break;
    }
    case Stmt::Del: {
        std::string t = exprType(s->e);
        ind();
        std::string varName = s->e->k == Expr::Var ? s->e->a : "";
        auto na = newAllocs.find(varName);
        if (na != newAllocs.end()) {
            // new �������ڴ棺�� scalar / ����ֱ� delete / delete[]
            std::string raw = t == "pry::Val" ? "((" + genVal(s->e) + ").ptr())"
                                              : genLValueRaw(s->e);
            bodyOut << (na->second.second ? "delete[] " : "delete ") << "(" << na->second.first
                    << "*)" << raw << ";\n";
        } else if (stackPtrs.count(varName)) {
            // &x �õ�����ջ��ַ�������ڱ����������del ֻ���ָ��
            bodyOut << "// del " << varName << "��ջ��ַ�����ͷ�\n";
        } else if (t == "pry::Val") {
            bodyOut << "pry::freep(" << genVal(s->e) << ");\n";
        } else if (t == "unsigned char*" || t == "void*") {
            bodyOut << "std::free((void*)(" << genLValueRaw(s->e) << "));\n";
        } else {
            bodyOut << "delete " << genLValueRaw(s->e) << ";\n";
        }
        break;
    }
    case Stmt::Ret: {
        ind();
        if (!inFunc) bodyOut << "return 0;\n";
        else if (s->e) bodyOut << "return " << convert(genVal(s->e), curRetType) << ";\n";
        else bodyOut << "return " << defaultFor(curRetType.empty() ? "pry::Val" : curRetType)
                     << ";\n";
        break;
    }
    case Stmt::Break: ind(); bodyOut << "break;\n"; break;
    case Stmt::Continue: ind(); bodyOut << "continue;\n"; break;
    case Stmt::If: {
        bool first = true;
        for (auto &b : s->branches) {
            ind();
            if (b.cond) {
                bodyOut << (first ? "if" : "else if") << " (pry::truthy(" << genVal(b.cond)
                        << ")) {\n";
            } else {
                bodyOut << "else {\n";
            }
            depth++;
            emitBlock(b.body);
            depth--;
            ind();
            bodyOut << "}\n";
            first = false;
        }
        break;
    }
    case Stmt::While: {
        ind();
        bodyOut << "while (pry::truthy(" << genVal(s->e) << ")) {\n";
        depth++;
        emitBlock(s->body);
        depth--;
        ind();
        bodyOut << "}\n";
        break;
    }
    case Stmt::ForNum: {
        std::string a = genVal(s->exprs[0]);
        std::string b = genVal(s->exprs[1]);
        std::string stepVal = s->exprs.size() > 2 ? genVal(s->exprs[2]) : "pry::Val(1LL)";
        // �Ͻ� / ����ֻ��ֵһ�Σ��� range() һ�£�������ÿ�ֶ������������ʽ
        std::string tb = "__b" + std::to_string(uid++);
        std::string ts = "__st" + std::to_string(uid++);
        bool hasStep = s->exprs.size() > 2;
        ind();
        bodyOut << "{\n";
        std::string pad((size_t)depth * 2 + 4, ' ');
        bodyOut << pad << "long long " << tb << " = (" << b << ").asInt();\n";
        bodyOut << pad << "long long " << ts << " = (" << stepVal << ").asInt();\n";
        if (hasStep)
            bodyOut << pad << "if (" << ts << " == 0) pry::pry_err(\"for ��������Ϊ 0\");\n";
        bodyOut << pad << "for (long long " << s->name << " = (" << a << ").asInt(); "
                << (hasStep ? "true" : s->name + " < " + tb) << "; " << s->name << " += " << ts
                << ") {\n";
        if (hasStep) {
            // ��������ҲҪ�ܽ���
            bodyOut << pad << "  if ((" << ts << " >= 0 && " << s->name << " >= " << tb << ") || ("
                    << ts << " < 0 && " << s->name << " <= " << tb << ")) break;\n";
        }
        depth++;  // ��Կ� +1������ push ������
        push();
        declare(s->name, "long long");
        for (auto &st : s->body) emitStmt(st);
        pop();
        depth--;
        ind();
        bodyOut << "  }\n";
        ind();
        bodyOut << "}\n";
        break;
    }
    case Stmt::ForIn: {
        std::string tmp = "__it" + std::to_string(uid++);
        ind();
        bodyOut << "{\n";
        ind();
        bodyOut << "  pry::List " << tmp << " = pry::iterable(" << genVal(s->e) << ");\n";
        ind();
        bodyOut << "  for (pry::Val " << s->name << " : " << tmp << ") {\n";
        depth += 2;
        push();
        declare(s->name, "pry::Val");
        for (auto &st : s->body) emitStmt(st);
        pop();
        depth -= 2;
        ind();
        bodyOut << "  }\n";
        ind();
        bodyOut << "}\n";
        break;
    }
    }
}

// ---------- ����ӿ� ----------
std::string generate(const std::vector<StmtP> &prog, const std::string &srcFile,
                     int silentBefore) {
    CodeGen g;
    g.srcFile = srcFile;
    std::filesystem::path p(srcFile);
    if (p.has_parent_path()) g.baseDir = p.parent_path().string();
    else g.baseDir = ".";

    g.collect(prog);

    // �������������壺pkuip ���û�����һ������Ҫ���е� C++ ����д�� headCpp
    g.depth = 0;
    g.srcFile = srcFile;
    for (int j = 0; j < (int)prog.size(); j++) {
        g.silent = (j < silentBefore);
        g.emitStmt(prog[j]);
    }

    std::ostringstream out;
    out << "// �� pryany �Զ����ɣ������ֹ��޸�\n"
        << "// Դ�ļ�: " << srcFile << "\n"
        << "#include \"pryany.h\"\n"
        << "using namespace pry;\n";

    // ���� cpp{ } ��ԭ���ŵ��ļ�ͷ��������д #include��struct���Լ��� C++ ������
    for (auto &st : prog)
        if (st->k == Stmt::RawCpp && st->declType == "head") out << st->name << "\n";

    // ȫ�ֱ���
    for (auto &kv : g.globalVars)
        out << kv.second << " " << kv.first << " = " << defaultFor(kv.second) << ";\n";

    // pkuip ���ڵ��õ����ɵ� C++ ���루����ȫ�ֱ���֮�󣬲������� pryany �Ķ��������
    out << g.headCpp.str();

    // ����ԭ�ͣ��� use �����ģ�麯������֤���ļ�ǰ�����Ҳ�ܱ����
    for (auto &kv : g.funcSigs) {
        const std::string &name = kv.first;
        auto rt = g.funcRet.find(name);
        out << (rt == g.funcRet.end() || rt->second.empty() ? "pry::Val" : rt->second) << " " << name
            << "(";
        for (size_t j = 0; j < kv.second.size(); j++) {
            if (j) out << ", ";
            out << kv.second[j];
        }
        out << ");\n";
    }

    // ��������
    g.emitFuncs(prog);
    out << g.declOut.str();

    // ������
    out << "int pry_main();\n"
        << "int main(int argc, char** argv) {\n"
        << "  (void)argc; (void)argv;\n"
        << "  try { return pry_main(); }\n"
        << "  catch (const std::exception& e) {\n"
        << "    std::cerr << \"����ʱ����: \" << e.what() << std::endl;\n"
        << "    return 1;\n"
        << "  }\n"
        << "}\n"
        << "int pry_main() {\n";

    out << g.bodyOut.str();
    out << "  return 0;\n}\n";
    return out.str();
}
