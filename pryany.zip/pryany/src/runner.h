
#ifndef PRY_RUNNER_H
#define PRY_RUNNER_H

#include <string>
#include <vector>

#include "pry_common.h"

std::string generate(const std::vector<StmtP> &prog, const std::string &srcFile,
                     int silentBefore = -1);

struct Runner {
    std::string runtimeDir;
    bool keepCpp = false;
    std::string workDir;

    std::string transpile(const std::string &src, const std::string &srcFile, int silentBefore,
                          std::string &err);

    bool compile(const std::string &cppCode, const std::string &cppPath, const std::string &binPath,
                 std::string &log, double &ms);

    int run(const std::string &binPath, double &ms);
};

std::string exeDir();
std::string findRuntimeDir();
std::string findGpp();
std::string readFile(const std::string &path, bool &ok);
std::string joinPath(const std::string &a, const std::string &b);

#endif
