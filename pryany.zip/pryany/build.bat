windres version.rc -O coff -o version.res
 g++ -std=c++17 -O2 src/\*.cpp -o pryany